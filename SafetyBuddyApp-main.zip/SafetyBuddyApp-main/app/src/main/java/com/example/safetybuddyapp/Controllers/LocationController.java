package com.example.safetybuddyapp.Controllers;

import android.location.Location;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.Models.FirebaseInstanceService;
import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.LocationRules;
import com.example.safetybuddyapp.Models.Places;
import com.example.safetybuddyapp.Models.Reports;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.Views.ILocationView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LocationController implements Constants {
    ILocationView locationView;
    FirebaseInstanceService firebaseInstanceService;
    User user;
    Group group;
    Places places;
    Reports reports;
    String title,body;

    public LocationController(ILocationView locationView){this.locationView = locationView;}

    public void OnUpdateUserLocation(Location location){
        user = new User();
        Task<Void> location_update = user.update_location(
                FirebaseAuth.getInstance().getUid(),
                location.getLatitude(),
                location.getLongitude());

    }


    public void OnLoadUserData(){
        String user_id = FirebaseAuth.getInstance().getUid();
        user = new User();

        Task<DocumentSnapshot> user_response = user.get_individual_user(user_id);

        user_response.addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                locationView.OnUserLoaded(documentSnapshot.toObject(User.class));
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
    }

    public void OnLoadGroups(){
        group = new Group();
        Task<QuerySnapshot> group_result = group.get_groups_for_user(FirebaseAuth.getInstance().getUid());
        group_result.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful() && !task.getResult().isEmpty()){
                    locationView.OnGroupsLoaded(task.getResult().toObjects(Group.class));
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });

    }

    public void OnLoadGroupUsers(String group_id){
        group = new Group();

        Task<DocumentSnapshot> group_result = group.get_single_group(group_id);

        group_result.addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                group = documentSnapshot.toObject(Group.class);
                OnLoadFriendsMarkers(group.getGroup_members());
            }
        });

    }

    public void OnLoadFriendsMarkers(List<String> member_id_list){
        user = new User();
        Task<QuerySnapshot> users = user.get_users_for_group(member_id_list);
        users.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()){
                    List<User> user_list = task.getResult().toObjects(User.class);
                    locationView.OnGroupUsersLoaded(user_list);
                }
            }
        });

    }

    public void OnLoadGroupLocations(String group_id){
        places = new Places();
        places.get_places_for_group(group_id).addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful() && !task.getResult().isEmpty()) {
                    locationView.OnLocationsLoaded(task.getResult().toObjects(Places.class));
                }
            }
        });
    }

    public void OnLoadGeofences(){
        places = new Places();
        group = new Group();
        group.get_groups_for_user(FirebaseAuth.getInstance().getUid()).addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful() && !task.getResult().isEmpty()){
                    for (Group group_instance: task.getResult().toObjects(Group.class)){
                        places.get_places_for_group(group_instance.getGroup_id()).addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if(task.isSuccessful() && !task.getResult().isEmpty()){
                                    locationView.OnGeofencesLoaded(task.getResult().toObjects(Places.class));
                                }
                            }
                        });
                    }
                }
            }
        });
    }

    public void OnLoadReports(){
        reports = new Reports();
        Task<QuerySnapshot> reports_response = reports.load_user_reports();


        reports_response.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful() && !task.getResult().isEmpty()) {
                    locationView.OnReportsLoaded(task.getResult().toObjects(Reports.class));
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
    }

    public void OnCreateReport(String reason, Location location){
        reports = new Reports();
        reports.setReport_id(UUID.randomUUID().toString());
        reports.setReport_date(new Date());
        reports.setReport_type(reason);
        reports.setReport_latitude(location.getLatitude());
        reports.setReport_longitude(location.getLongitude());
        reports.create_report();

    }

    public void OnUpdateDefaultGroup(String group_id){
        String user_id = FirebaseAuth.getInstance().getUid();
        user = new User();

        Task<Void> update_response = user.update_default_group(user_id,group_id);

        update_response.addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
    }




    public void OnToggleEmergencyMode(User user){

        boolean mode = user.getEmergency_mode();
        mode = !mode;
        user.update_emergency_status(FirebaseAuth.getInstance().getUid(), mode).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
            }
        });
    }


    public void OnLoadRuleStatus(String user_id){
        LocationRules rules = new LocationRules();

        rules.get_rule(user_id).addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if(documentSnapshot.exists()){
                    LocationRules rule_gotten = documentSnapshot.toObject(LocationRules.class);
                    locationView.OnRuleApplied(rule_gotten.is_rule_applicable(rule_gotten));

                }
                else{
                    locationView.OnRuleApplied(true);
                }
            }
        });

    }



    public void OnStopEmergencyMode(String security_code){
        user = new User();

        user.get_individual_user(FirebaseAuth.getInstance().getUid()).addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                user = documentSnapshot.toObject(User.class);
                if(user.getSecurity_code().equals(security_code)){
                    locationView.OnEmergencyModeStopped();
                    OnNotifyEmergency(user.getName(), EMERGENCY_MODE_DEACTIVATED);

                }
                else if(user.getFalse_security_code().equals(security_code)){
                    locationView.OnEmergencyModeStoppedFake();
                    OnNotifyEmergency(user.getName(),EMERGENCY_MODE_COERCION_MODE);
                }
                else{
                    locationView.OnInvalidSecurityCode();

                }
            }
        });
    }

    public void OnNotifyEmergency(String username,int emergency_type){
        group = new Group();
        firebaseInstanceService = new FirebaseInstanceService();

        group.get_groups_for_user(FirebaseAuth.getInstance().getUid()).addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    List<Group> groups = task.getResult().toObjects(Group.class);
                    for(Group group1 : groups){
                        for(String user1 : group1.getGroup_members()){
                            user.get_individual_user(user1).addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                @Override
                                public void onSuccess(DocumentSnapshot documentSnapshot) {
                                    User group_user = documentSnapshot.toObject(User.class);
                                    if(!group_user.getId().equals(FirebaseAuth.getInstance().getUid())) {
                                        if(emergency_type == EMERGENCY_MODE_COERCION_MODE){
                                            title = username + " has entered their Coersion Code!";
                                            body = "Someoene has asked the user to toggle off emergency!";
                                        }
                                        if(emergency_type == EMERGENCY_MODE_DEACTIVATED){
                                            title = username + " is okay!";
                                            body = "User has turned off emergency mode!";

                                        }
                                        else{
                                            body = username + " has triggered their SOS mode!";
                                            title = "SOS Mode Triggered!!!";
                                        }
                                        firebaseInstanceService.onMessageSent(group_user.getFcm_token(),username, title, body);
                                    }

                                }
                            });
                        }

                    }

                }
            }
        });
    }






}
