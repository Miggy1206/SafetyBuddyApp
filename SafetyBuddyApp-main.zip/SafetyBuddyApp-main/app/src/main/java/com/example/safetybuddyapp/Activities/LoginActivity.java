package com.example.safetybuddyapp.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.test.espresso.idling.CountingIdlingResource;

import com.example.safetybuddyapp.Controllers.LoginController;
import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.Views.ILoginView;
import com.google.android.material.textfield.TextInputLayout;

public class LoginActivity extends AppCompatActivity implements ILoginView, Constants {

    EditText email, password;
    TextInputLayout emailLayout, passwordLayout;
    Button loginButton;

    LoginController loginController;

    private CountingIdlingResource mIdlingResource = new CountingIdlingResource("Login");
    public CountingIdlingResource getIdlingResource() {
        return mIdlingResource;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        loginController = new LoginController(this);


        email = (EditText)  findViewById(R.id.email);
        password = (EditText) findViewById(R.id.password);

        emailLayout = (TextInputLayout) findViewById(R.id.emailLayout);
        passwordLayout = (TextInputLayout) findViewById(R.id.passwordLayout);
        loginButton = (Button) findViewById(R.id.loginButton);


        email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                emailLayout.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        //
        password.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                passwordLayout.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearErrors();
                mIdlingResource.increment();
                loginController.OnLogin(email.getText().toString().trim(),password.getText().toString().trim());

            }
        });
    }

    public void clearErrors(){
        emailLayout.setErrorEnabled(false);
        passwordLayout.setErrorEnabled(false);
    }


    @Override
    public void OnLoginSuccess() {
        mIdlingResource.decrement();
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
    }



    @Override
    public void OnLoginError(String error_message) {
        mIdlingResource.decrement();
    }


    @Override
    public void OnInvalidEmail(int decline_code) {
        if(decline_code == EMPTY_FIELD){
            emailLayout.setError(EMAIL_EMPTY_FIELD_ERROR);
        }
        else if(decline_code == INVALID_FORMAT){
            emailLayout.setError(EMAIL_INVALID_FORMAT_ERROR);
        }
        else if(decline_code == UNVERIFIED_FIELD){
            emailLayout.setError(EMAIL_NOT_VERIFIED_ERROR);
        }

    }


    @Override
    public void OnInvalidPassword(int decline_code) {
        if(decline_code == EMPTY_FIELD){
            passwordLayout.setError(PASSWORD_EMPTY_FIELD_MESSAGE);
        }
        else if(decline_code == INVALID_FORMAT){
            passwordLayout.setError(PASSWORD_INVALID_FORMAT_ERROR);
        }

    }
}