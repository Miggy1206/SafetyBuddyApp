package com.example.safetybuddyapp.Fragments;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.safetybuddyapp.Controllers.ProfileController;
import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.Views.IProfileView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProfileFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileFragment extends Fragment implements IProfileView, Constants {


    private ProfileController profileController;
    private User user;
    private TextView email_textview, birth_textview, name_textview,phone_textview, save_textview;
    private ImageView profile_imageview;
    private ActivityResultLauncher<String> takePhoto;
    private Button change_image_button, save_details_button, profile_back_button;
    private TextInputLayout nameLayout, phoneLayout;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        profileController = new ProfileController(this);
        profile_imageview = view.findViewById(R.id.profile_imageview);
        change_image_button = view.findViewById(R.id.change_image_button);
        email_textview = view.findViewById(R.id.email_textview);
        birth_textview = view.findViewById(R.id.birth_textview);
        name_textview = view.findViewById(R.id.name_textview);
        phone_textview = view.findViewById(R.id.phone_textview);
        save_details_button = view.findViewById(R.id.save_details_button);
        nameLayout = view.findViewById(R.id.nameLayout);
        phoneLayout = view.findViewById(R.id.phoneLayout);
        save_textview = view.findViewById(R.id.save_textview);
        profile_back_button = view.findViewById(R.id.profile_back_button);

        profileController.OnLoadUser();

        name_textview.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                save_textview.setText(null);
                nameLayout.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        phone_textview.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                save_textview.setText(null);
                phoneLayout.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        profile_back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getParentFragmentManager().popBackStack();
            }
        });

        takePhoto = registerForActivityResult(new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
            @Override
            public void onActivityResult(Uri o) {
                InputStream imageStream = null;
                try {
                    imageStream = getContext().getContentResolver().openInputStream(o);
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
                Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                profile_imageview.setImageBitmap(selectedImage);
                profileController.OnUpdateProfileImage(selectedImage);
            }
        });

        change_image_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePhoto.launch("image/*");
            }
        });

        save_details_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save_textview.setText(null);
                profileController.OnSaveProfileDetails(name_textview.getText().toString(),phone_textview.getText().toString());
            }
        });



        return view;
    }

    @Override
    public void OnUserLoaded(User user) {
        this.user = user;
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String date_of_birth = formatter.format(user.getDate_of_birth());
        email_textview.setText(user.getEmail());
        birth_textview.setText(date_of_birth);
        name_textview.setText(user.getName());
        phone_textview.setText(user.getPhone_number());


    }

    @Override
    public void OnProfileImageLoaded(Bitmap profile_image) {
        profile_imageview.setImageBitmap(profile_image);
    }

    @Override
    public void OnInvalidName(int decline_code) {
        if(decline_code == EMPTY_FIELD){
            nameLayout.setError(NAME_EMPTY_FIELD_ERROR);
        }
    }

    @Override
    public void OnInvalidNumber(int decline_code) {
        if(decline_code == EMPTY_FIELD){
            phoneLayout.setError(PHONE_NUMBER_EMPTY_FIELD_ERROR);
        }
        else if(decline_code == INVALID_FORMAT){
            phoneLayout.setError(PHONE_NUMBER_INVALID_FORMAT_ERROR);
        }
    }

    @Override
    public void OnSaveSuccess() {
        save_textview.setText("Saved✔");
    }

}