package com.example.safetybuddyapp.Controllers;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Fragments.ManageRequestFragment;
import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.GroupRequests;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.Views.IGroupRequestsView;
import com.example.safetybuddyapp.Views.IManageRequestView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

public class ManageRequestController implements Constants {
    private IManageRequestView manageRequestView;
    private GroupRequests requests;
    private Group group;
    private User user;

    public ManageRequestController(IManageRequestView manageRequestView){this.manageRequestView = manageRequestView;}

    public void OnLoadRequest(String request_id){
        requests = new GroupRequests();
        Task<DocumentSnapshot> request_response = requests.get_specific_request(FirebaseAuth.getInstance().getUid(), request_id);

        request_response.addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if(documentSnapshot.exists()) {
                    requests = documentSnapshot.toObject(GroupRequests.class);
                    manageRequestView.OnRequestLoaded(requests);
                    OnLoadRequestGroup(requests.getRequest_group_id());
                }
            }
        });

    }
    public void OnLoadRequestGroup(String request_group_id){
        group = new Group();
        Task<DocumentSnapshot> group_result = group.get_single_group(request_group_id);

        group_result.addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                group = documentSnapshot.toObject(Group.class);
                manageRequestView.OnGroupLoaded(group);
            }
        });


    }


    public void OnLoadGroupMembers(List<String> group_id){
        user = new User();
        Task<QuerySnapshot> user_results = user.get_users_for_group(group_id);
        user_results.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful() && !task.getResult().isEmpty()){
                    manageRequestView.OnGroupMembersLoaded(task.getResult().toObjects(User.class));
                }
            }
        });

    }
    public void OnAcceptRequest(GroupRequests request, Group groups){
        requests = new GroupRequests();
        group = new Group();
        Task<Void> group_result = group.add_user_to_group(groups.getGroup_id(),FirebaseAuth.getInstance().getUid());
        group_result.addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Task<Void> request_result = requests.update_request(FirebaseAuth.getInstance().getUid(), request.getRequest_id(),"accepted");
                request_result.addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        manageRequestView.OnRequestAccepted();
                    }
                });
            }
        });


    }
    public void OnDeclineRequest(GroupRequests request){
        requests = new GroupRequests();
        Task<Void> request_result = requests.update_request(FirebaseAuth.getInstance().getUid(), request.getRequest_id(),"declined");
        request_result.addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                manageRequestView.OnRequestDeclined();
            }
        });

    }
}
