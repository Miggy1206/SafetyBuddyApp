package com.example.safetybuddyapp.Controllers;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.Views.ILoginView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;

public class LoginController implements Constants {


    private ILoginView loginView;
    User user = new User();


    //Initialise login view
    public LoginController(ILoginView loginView){
        this.loginView = loginView;
    }


    //On login method actioned on click of sign in button
    public void OnLogin(String email, String password) {
        //Validates email and password and returns relating codes
        int email_code = user.is_valid_email(email);
        int password_code = user.is_valid_password(password);

        //Returns decline code to UI, prompting user of errors
        if(email_code != VALID_FORMAT){
            loginView.OnInvalidEmail(email_code);
        }
        if(password_code != VALID_FORMAT){
            loginView.OnInvalidPassword(password_code);
        }

        //If validation is successful, then call login result from User Model
        if (email_code == VALID_FORMAT && password_code == VALID_FORMAT) {
            Task<AuthResult> login_result = user.login_user(email, password);
            login_result.addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                @Override
                public void onSuccess(AuthResult authResult) {
                    //If a matching user is found, check email verification status.
                    //if (authResult.getUser().isEmailVerified()) {
                        //Return successful response to UI.
                        loginView.OnLoginSuccess();
                    //}
                    //else {
                        //Prompts user to verify email.
                        //loginView.OnInvalidEmail(UNVERIFIED_FIELD);
                    //}
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    //If matching user is not found, prompt user that email/password combination is incorrect
                    loginView.OnLoginError(INVALID_LOGIN_DETAILS_ERROR);
                }
            });
        }
        else{
            loginView.OnLoginError("error");
        }
    }
}
