package com.example.safetybuddyapp.Activities;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.test.espresso.idling.CountingIdlingResource;

import com.example.safetybuddyapp.Controllers.RegisterController;
import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.Views.IRegisterView;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity implements IRegisterView, Constants {

    DatePickerDialog date_of_birth_picker_dialog;
    EditText email, name, phone_number, date_of_birth, confirm_password, password;
    TextInputLayout emailLayout, nameLayout, dateOfBirthLayout, phoneNumberLayout, passwordLayout, confirmPasswordLayout;
    Button registerButton;

    RegisterController registerController;

    private CountingIdlingResource mIdlingResource = new CountingIdlingResource("Register");
    public CountingIdlingResource getIdlingResource() {
        return mIdlingResource;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        registerController = new RegisterController(this);


        email = findViewById(R.id.email);
        name = findViewById(R.id.name);
        phone_number = findViewById(R.id.phone_number);
        date_of_birth = findViewById(R.id.date_of_birth);
        password = findViewById(R.id.password);
        confirm_password = findViewById(R.id.confirmPassword);

        emailLayout = findViewById(R.id.emailLayout);
        nameLayout = findViewById(R.id.nameLayout);
        phoneNumberLayout = findViewById(R.id.phoneNumberLayout);
        dateOfBirthLayout = findViewById(R.id.dateOfBirthLayout);
        passwordLayout = findViewById(R.id.passwordLayout);
        confirmPasswordLayout = findViewById(R.id.confirmPasswordLayout);

        registerButton = findViewById(R.id.registerButton);

        //Email text listener
        email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                emailLayout.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        //Name text listener
        name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                nameLayout.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        //Phone number text listener
        phone_number.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                phoneNumberLayout.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        date_of_birth.requestFocus();
        date_of_birth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dateOfBirthLayout.setErrorEnabled(false);
                openCalendarView();
            }
        });

        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                passwordLayout.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        confirm_password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                confirmPasswordLayout.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearErrors();
                mIdlingResource.increment();
                registerController.OnRegistration(
                        email.getText().toString().trim(),
                        name.getText().toString().trim(),
                        phone_number.getText().toString().trim(),
                        date_of_birth.getText().toString(),
                        password.getText().toString().trim(),
                        confirm_password.getText().toString().trim());


            }
        });


    }

    public void openCalendarView(){
        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH);
        int year = calendar.get(Calendar.YEAR);

        date_of_birth_picker_dialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                int month_s = month + 1;
                String strMonth = "" + month_s;
                String strDayOfMonth = "" + dayOfMonth;
                if (month < 10){
                    strMonth = "0" + strMonth;
                }
                if (dayOfMonth < 10){
                    strDayOfMonth = "0"+strDayOfMonth;
                }
                String date = strDayOfMonth + "/"+strMonth+"/"+year;
                date_of_birth.setText(date);
            }
        }, year, month, day);

        date_of_birth_picker_dialog.setTitle("Select Date of Birth");
        date_of_birth_picker_dialog.show();
    }

    public void clearErrors(){
        emailLayout.setErrorEnabled(false);
        nameLayout.setErrorEnabled(false);
        phoneNumberLayout.setErrorEnabled(false);
        dateOfBirthLayout.setErrorEnabled(false);
        passwordLayout.setErrorEnabled(false);
        confirmPasswordLayout.setErrorEnabled(false);
    }

    @Override
    public void OnRegistrationSuccess() {
        mIdlingResource.decrement();
        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
        startActivity(intent);

    }

    @Override
    public void OnRegistrationError(String error_message) {
        mIdlingResource.decrement();
    }

    @Override
    public void OnInvalidEmail(int decline_code) {
        if(decline_code == EMPTY_FIELD){
            emailLayout.setError(EMAIL_EMPTY_FIELD_ERROR);
        }
        else if(decline_code == INVALID_FORMAT){
            emailLayout.setError(EMAIL_INVALID_FORMAT_ERROR);
        }
        else if(decline_code == ALREADY_IN_USE){
            emailLayout.setError(EMAIL_IN_USE_ERROR);
        }
    }

    @Override
    public void OnInvalidPassword(int decline_code) {
        if(decline_code == EMPTY_FIELD){
            passwordLayout.setError(PASSWORD_EMPTY_FIELD_MESSAGE);
        }
        else if(decline_code == INVALID_FORMAT){
            passwordLayout.setError(PASSWORD_INVALID_FORMAT_ERROR);
        }
    }

    @Override
    public void OnInvalidName(int decline_code) {
        if(decline_code == EMPTY_FIELD){
            nameLayout.setError(NAME_EMPTY_FIELD_ERROR);
        }

    }

    @Override
    public void OnInvalidPhoneNumber(int decline_code) {
        if(decline_code == EMPTY_FIELD){
            phoneNumberLayout.setError(PHONE_NUMBER_EMPTY_FIELD_ERROR);
        }
        else if(decline_code == INVALID_FORMAT){
            phoneNumberLayout.setError(PHONE_NUMBER_INVALID_FORMAT_ERROR);
        }

    }

    @Override
    public void OnInvalidDateOfBirth(int decline_code) {
        if(decline_code == ILLOGICAL_FIELD){
            dateOfBirthLayout.setError(BIRTH_ILLOGICAL_FIELD_ERROR);
        }
        else if(decline_code == AGAINST_T_AND_TS){
            dateOfBirthLayout.setError(BIRTH_T_AND_TS_ERROR);
        }
        else if(decline_code == EMPTY_FIELD){
            dateOfBirthLayout.setError(BIRTH_EMPTY_FIELD_ERROR);
        }

    }

    @Override
    public void OnInvalidConfirmPassword(int decline_code) {
        if(decline_code == EMPTY_FIELD){
            confirmPasswordLayout.setError(PASSWORD_EMPTY_FIELD_MESSAGE);
        }
        else if(decline_code == INVALID_FORMAT){
            confirmPasswordLayout.setError(PASSWORD_INVALID_FORMAT_ERROR);
        }
    }

    @Override
    public void OnInvalidMatchingPasswords(int decline_code) {
        if (decline_code == NOT_MATCHING_FIELDS){
            passwordLayout.setError(NOT_MATCHING_PASSWORDS_ERROR);
            confirmPasswordLayout.setError(NOT_MATCHING_PASSWORDS_ERROR);
        }

    }

}