package com.example.safetybuddyapp.Views;

import com.example.safetybuddyapp.Models.GroupRequests;

import java.util.List;

public interface IGroupRequestsView {
    void OnPendingRequestsLoaded(List<GroupRequests> pending_requests);
    void OnAcceptedRequestsLoaded(List<GroupRequests> accepted_requests);
    void OnDeclinedRequestsLoaded(List<GroupRequests> declined_requests);
}
