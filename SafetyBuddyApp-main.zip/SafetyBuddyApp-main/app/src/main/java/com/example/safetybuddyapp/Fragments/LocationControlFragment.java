package com.example.safetybuddyapp.Fragments;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.ToggleButton;

import com.example.safetybuddyapp.Controllers.LocationControlsController;
import com.example.safetybuddyapp.Models.LocationRules;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.Views.ILocationControlsView;
import com.google.firebase.auth.FirebaseAuth;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link LocationControlFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LocationControlFragment extends Fragment implements ILocationControlsView {

    LocationControlsController locationControlsController;
    TextView start_time_picker, end_time_picker, frequency_text;
    Button rule_button, delete_rule_button;
    int start_hour,start_minute;
    ToggleButton location_toggle;
    SeekBar frequency_seekbar;
    Button control_back_button;
    int[] list = new int[]{5,10,15,30,60,90,120,180,240,300};


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_location_control, container, false);


        locationControlsController = new LocationControlsController(this);
        start_time_picker = view.findViewById(R.id.start_time_picker);
        end_time_picker = view.findViewById(R.id.end_time_picker);
        rule_button = view.findViewById(R.id.rule_button);
        delete_rule_button = view.findViewById(R.id.delete_rule_button);
        location_toggle = view.findViewById(R.id.location_toggle);
        frequency_seekbar = view.findViewById(R.id.frequency_seekbar);
        frequency_text = view.findViewById(R.id.frequency_text);
        control_back_button = view.findViewById(R.id.controls_back_button);

        locationControlsController.OnLoadLocationSettings();
        locationControlsController.OnLocationStatusLoaded();


        control_back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getParentFragmentManager().popBackStack();
            }
        });


        location_toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                locationControlsController.OnToggleLocation();
            }
        });


        frequency_seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                int frequency_time = list[i];
                String frequency_string;
                if(frequency_time / 60 >= 1){
                    frequency_string = String.valueOf(frequency_time / (double)60) + " minutes";
                }
                else {
                    frequency_string = String.valueOf(frequency_time) + " seconds";
                }
                frequency_text.setText(frequency_string);
                locationControlsController.OnUpdateFrequency(frequency_time);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });



        start_time_picker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                time_dialog(start_time_picker);
            }
        });

        end_time_picker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                time_dialog(end_time_picker);
            }
        });

        rule_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                locationControlsController.OnUpdateTimeBasedRule(start_time_picker.getText().toString(),end_time_picker.getText().toString());
            }
        });

        delete_rule_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                locationControlsController.OnDeleteRule(FirebaseAuth.getInstance().getUid());
            }
        });



        return view;
    }

    private void time_dialog(TextView view){
        TimePickerDialog.OnTimeSetListener onTimeSetListener =  new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int i, int i1) {
                start_hour = i;
                start_minute = i1;
                view.setText(String.format(Locale.getDefault(),"%02d:%02d",start_hour,start_minute));
            }
        };
        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(), AlertDialog.THEME_HOLO_DARK,onTimeSetListener,start_hour,start_minute,true);
        timePickerDialog.setTitle("Select Time");
        timePickerDialog.show();

    }

    @Override
    public void OnRuleDeleted() {
        start_time_picker.setText(null);
        end_time_picker.setText(null);
    }

    @Override
    public void OnRuleLoaded(LocationRules rule) {
        String start, end;
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm", Locale.getDefault());
        start_time_picker.setText(formatter.format(rule.getStart_time()));
        end_time_picker.setText(formatter.format(rule.getEnd_time()));
        delete_rule_button.setClickable(true);
        delete_rule_button.setVisibility(View.VISIBLE);
    }


    @Override
    public void OnLocationStatusLoaded(User user) {
        location_toggle.setChecked(user.isLocation_sharing());
        for (int i = 0 ; i < list.length ; i++){
            if(list[i] == user.getUpdate_frequency()){
                frequency_seekbar.setProgress(i);
            }
        }
    }

    @Override
    public void OnLocationToggled(boolean location_status) {
        location_toggle.setChecked(location_status);
    }
}