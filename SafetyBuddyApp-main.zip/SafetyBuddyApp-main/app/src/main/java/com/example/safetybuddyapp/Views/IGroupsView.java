package com.example.safetybuddyapp.Views;

import com.example.safetybuddyapp.Models.Group;

import java.util.List;

public interface IGroupsView {
    void OnGroupsLoaded(List<Group> group_list);
    void OnGroupAddedSuccessful();
    void OnGroupAddedError();
}
