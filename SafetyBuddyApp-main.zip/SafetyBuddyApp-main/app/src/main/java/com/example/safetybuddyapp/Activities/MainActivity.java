package com.example.safetybuddyapp.Activities;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;

import android.Manifest;
import android.app.ActivityManager;
import android.app.DownloadManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.safetybuddyapp.Fragments.CodesFragment;
import com.example.safetybuddyapp.Fragments.GroupsFragment;
import com.example.safetybuddyapp.Fragments.HelpFragment;
import com.example.safetybuddyapp.Fragments.LocationControlFragment;
import com.example.safetybuddyapp.Fragments.LocationFragment;
import com.example.safetybuddyapp.Fragments.ProfileFragment;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.databinding.ActivityMainBinding;
import com.google.android.material.sidesheet.SideSheetDialog;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.messaging.FirebaseMessaging;


import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;

    @Override
    public void onStart() {
        super.onStart();

    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.bottomNavigationView.setSelectedItemId(R.id.location);
        LocationFragment locationFragment = new LocationFragment();


        if(isBiometricAvailable()){
            showBiometricPrompt();
        }
        else{

        }





        replaceFragment(locationFragment);





        getFirebaseCloudMessagingToken();




        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.location) {
                replaceFragment(locationFragment);
            } else if (item.getItemId() == R.id.groups) {
                replaceFragment(new GroupsFragment());
            }
            else if (item.getItemId() == R.id.help) {
                replaceFragment(new HelpFragment());
            }
            return true;
        });


        binding.TopBar.setOnMenuItemClickListener(item-> {
            if (item.getItemId() == R.id.profile_button) {
                SideSheetDialog sideSheetDialog = new SideSheetDialog(this);
                View profile_view = LayoutInflater.from(this).inflate(R.layout.profile_side_sheet,null);
                sideSheetDialog.setContentView(profile_view);
                Button profile_close_button = profile_view.findViewById(R.id.profile_close_button);
                Button personal_details_button = profile_view.findViewById(R.id.personal_details_button);
                Button sign_out_button = profile_view.findViewById(R.id.sign_out_button);
                Button location_controls_button = profile_view.findViewById(R.id.location_controls_button);
                Button security_codes_button = profile_view.findViewById(R.id.security_codes_button);


                sideSheetDialog.show();


                location_controls_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        replaceFragment(new LocationControlFragment());
                        sideSheetDialog.hide();
                    }
                });

                profile_close_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        sideSheetDialog.hide();
                    }
                });

                personal_details_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        replaceFragment(new ProfileFragment());
                        sideSheetDialog.hide();
                    }
                });

                security_codes_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        replaceFragment(new CodesFragment());
                        sideSheetDialog.hide();

                    }
                });



                sign_out_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        FirebaseAuth.getInstance().signOut();
                        Intent intent = new Intent(MainActivity.this,StartActivity.class);
                        startActivity(intent);
                    }
                });

            }
            return true;
        });

    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment).addToBackStack(null).setReorderingAllowed(false);
        fragmentTransaction.commit();
    }


    private void getFirebaseCloudMessagingToken() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        String token = task.getResult();
                        User user = new User();
                        user.update_token(FirebaseAuth.getInstance().getUid(), token);
                    } else {
                        Log.e("FCM Token", "Failed to get token");
                    }
                });
    }





    //Check for biometric availability
    private boolean isBiometricAvailable(){
        androidx.biometric.BiometricManager biometricManager = androidx.biometric.BiometricManager.from(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
        }
        return false;
    }


    @RequiresApi(api = Build.VERSION_CODES.P)
    private void showBiometricPrompt(){
        Executor executor = getMainExecutor();
        FragmentActivity activity = this;
        androidx.biometric.BiometricPrompt.PromptInfo promptInfo = new androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                .setTitle("Biometric Authentication")
                .setSubtitle("Use your fingerprint to authenticate")
                .setNegativeButtonText("Cancel")
                .build();


        BiometricPrompt biometricPrompt = new BiometricPrompt(activity, executor, new BiometricPrompt.AuthenticationCallback(){
            @Override
            public void onAuthenticationError(int error_code, CharSequence errString){
                super.onAuthenticationError(error_code,errString);
                FirebaseAuth.getInstance().signOut();
                finish();
            }
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){
                super.onAuthenticationSucceeded(result);
            }
            @Override
            public void onAuthenticationFailed(){
                super.onAuthenticationFailed();
                FirebaseAuth.getInstance().signOut();
                finish();
            }
        });
        biometricPrompt.authenticate(promptInfo);
    }







}