package com.example.safetybuddyapp.Views;

import com.example.safetybuddyapp.Models.LocationRules;
import com.example.safetybuddyapp.Models.User;

public interface ILocationControlsView {
    void OnRuleDeleted();
    void OnRuleLoaded(LocationRules rule);
    void OnLocationStatusLoaded(User user);
    void OnLocationToggled(boolean location_status);
}
