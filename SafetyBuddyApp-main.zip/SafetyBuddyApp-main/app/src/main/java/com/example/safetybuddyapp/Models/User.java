package com.example.safetybuddyapp.Models;

import android.util.Patterns;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class User implements Constants{
    private String id;
    private String email;
    private String name;
    private String phone_number;
    private Date date_of_birth;
    private boolean location_sharing;
    private Double current_latitude;
    private Double current_longitude;
    private String profile_image_link;
    private String security_code;
    private String false_security_code;
    private String default_group;
    private boolean emergency_mode;
    private String fcm_token;
    private int update_frequency;

    public User(){}


    //User setter methods
    public void setId(String id) { this.id = id;}
    public void setEmail(String email) { this.email = email;}
    public void setName(String name) { this.name = name;}
    public void setPhone_number(String phone_number) { this.phone_number = phone_number; }
    public void setDate_of_birth(Date date_of_birth) { this.date_of_birth = date_of_birth;}
    public void setLocation_sharing(boolean location_sharing) { this.location_sharing = location_sharing;}
    public void setCurrent_latitude(Double current_latitude) { this.current_latitude = current_latitude; }
    public void setCurrent_longitude(Double current_longitude) { this.current_longitude = current_longitude; }
    public void setProfile_image_link(String profile_image_link) { this.profile_image_link = profile_image_link; }
    public void setSecurity_code(String security_code) { this.security_code = security_code; }
    public void setFalse_security_code(String false_security_code) { this.false_security_code = false_security_code;}
    public void setDefault_group(String default_group) { this.default_group = default_group;}
    public void setEmergency_mode(boolean emergency_mode) { this.emergency_mode = emergency_mode; }
    public void setUpdate_frequency(int update_frequency) { this.update_frequency = update_frequency; }
    public void setFcm_token(String fcm_token){this.fcm_token = fcm_token;}

    //User getter methods
    public String getId() { return id;}
    public String getEmail() { return email;}
    public String getName() { return name;}
    public String getPhone_number() { return phone_number; }
    public Date getDate_of_birth() { return date_of_birth;}
    public boolean isLocation_sharing() { return location_sharing;}
    public Double getCurrent_latitude() { return current_latitude; }
    public Double getCurrent_longitude() { return current_longitude; }
    public String getProfile_image_link() { return profile_image_link; }
    public String getSecurity_code() { return security_code; }
    public String getFalse_security_code() { return false_security_code; }
    public String getDefault_group() { return default_group; }
    public boolean getEmergency_mode() { return emergency_mode; }
    public int getUpdate_frequency() { return update_frequency; }
    public String getFcm_token() { return fcm_token; }

    public Date StringToDateOfBirth(String date_of_birth) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        Date correct_formatted_date_of_birth = null;
        if (!date_of_birth.isEmpty()) {
            try {
                correct_formatted_date_of_birth = formatter.parse(date_of_birth);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
        }

        return correct_formatted_date_of_birth;
    }


    //Validation methods

    public int is_valid_email(String email) {
        if(email.isEmpty()){
            return EMPTY_FIELD;
        }
        else if(!email.matches(Patterns.EMAIL_ADDRESS.pattern())){
            return INVALID_FORMAT;

        }
        else{
            return VALID_FORMAT;
        }
    }

    public int is_valid_password(String password) {
        String pattern = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\\\S+$).{4,}$";
        if(password.isEmpty()){
            return EMPTY_FIELD;
        }
        return VALID_FORMAT;
    }


    public int is_valid_name(String name) {
        if (name.isEmpty()){
            return EMPTY_FIELD;
        }
        return VALID_FORMAT;
    }

    public int is_valid_phone_number(String phone_number) {
        if(phone_number.isEmpty()){
            return EMPTY_FIELD;
        }
        else if (!phone_number.matches(Patterns.PHONE.pattern())){
            return INVALID_FORMAT;
        }
        else{
            return VALID_FORMAT;
        }
    }

    public int is_valid_date_of_birth(Date date_of_birth) {
        if(date_of_birth == null){
            return EMPTY_FIELD;
        }
        else if(date_of_birth.after(new Date())){
            return ILLOGICAL_FIELD;
        }
        else if(((new Date()).getTime()- date_of_birth.getTime())/1000 < (AGE_REQUIREMENT * 365 * 24 * 60 * 60)){
            return AGAINST_T_AND_TS;
        }
        else{
            return VALID_FORMAT;
        }
    }



    public int is_matching_password(String password, String confirm_password) {
        if (password.equals(confirm_password)){
            return MATCHING_FIELDS;
        }
        else{
            return NOT_MATCHING_FIELDS;
        }
    }


    public int is_valid_security_code(String security_code){
        if(security_code.isEmpty()){
            return EMPTY_FIELD;
        }
        else if(security_code.length() != 4){
            return INVALID_FORMAT;
        }
        return VALID_FORMAT;
    }

    public boolean is_matching_codes(String security_code,String false_security_code){
        return security_code.equals(false_security_code);
    }

    public  Task<DocumentSnapshot> get_individual_user(String user_id){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .get();
    }

    public  Task<QuerySnapshot> get_all_users(){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .get();
    }




    //Method to return user from Firebase Authentication - Login
    public Task<AuthResult> login_user(String email, String password){
        return FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password);
    }




    //Method to create a new user in Firebase Authentication - Register
    public Task<AuthResult> register_user(String email, String password){
        return FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password);
    }

    //Method to add user to firestore database - Hold additional user data (Attributes)
    public Task<Void> add_user_to_firestore(){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(this.id)
                .set(this);
    }


    public Task<Void> send_email_verification() {
        if(FirebaseAuth.getInstance().getCurrentUser() != null) {
            return FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification();
        }
        else{
            return null;
        }
    }




    public Task<QuerySnapshot> get_users_for_group(List<String> members){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .whereIn("id",members)
                .get();
    }

    public Task<QuerySnapshot> get_users_not_in_group(List<String> members){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .whereNotIn("id",members)
                .get();
    }

    public Task<Void> update_profile_image(String user_id,String new_image_link){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .update("profile_image_link",new_image_link);
    }

    public Task<Void> update_profile_details(String user_id,String user_name,String user_number){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .update("name",user_name,"phone_number",user_number);
    }
    public Task<Void> update_location_status(String user_id,boolean location_status){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .update("location_sharing",location_status);
    }

    public Task<Void> update_emergency_status(String user_id,boolean emergency_status){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .update("emergency_mode",emergency_status);
    }

    public Task<Void> update_default_group(String user_id,String group_id){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .update("default_group",group_id);
    }

    public Task<Void> update_location(String user_id,double current_latitude,double current_longitude){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .update("current_latitude",current_latitude,"current_longitude",current_longitude);
    }

    public Task<Void> update_frequency(String user_id, int frequency){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .update("update_frequency",frequency);
    }

    public Task<Void> update_token(String user_id, String token){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .update("fcm_token",token);
    }


    public Task<Void> update_security_codes(String user_id,String security_code,String false_security_code){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .update("security_code",security_code,"false_security_code",false_security_code);
    }



}
