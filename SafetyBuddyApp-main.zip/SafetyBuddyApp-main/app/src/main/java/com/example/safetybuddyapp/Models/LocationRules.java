package com.example.safetybuddyapp.Models;

import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.junit.Rule;

import java.time.LocalTime;
import java.util.Date;

public class LocationRules implements Constants{
    private String rule_id;
    private Date start_time;
    private Date end_time;

    public LocationRules(){}

    public void setRule_id(String rule_id) { this.rule_id = rule_id;}
    public void setStart_time(Date start_time) { this.start_time = start_time; }
    public void setEnd_time(Date end_time) { this.end_time = end_time; }

    public String getRule_id() { return rule_id; }
    public Date getStart_time() { return start_time; }
    public Date getEnd_time() { return end_time; }


    public Task<Void> create_rule(String user_id){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .collection(RULES_COLLECTION)
                .document(this.rule_id)
                .set(this);
    }
    public Task<DocumentSnapshot> get_rule(String user_id){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .collection(RULES_COLLECTION)
                .document(user_id)
                .get();
    }

    public Task<Void> delete_rule(String user_id){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .collection(RULES_COLLECTION)
                .document(user_id)
                .delete();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean is_rule_applicable(LocationRules rule){
        Date start_time = rule.getStart_time();
        Date end_time = rule.getEnd_time();
        int startHour = start_time.getHours();
        int startMinute = start_time.getMinutes();
        int endHour = end_time.getHours();
        int endMinute = end_time.getMinutes();

        LocalTime start = LocalTime.of(startHour, startMinute);
        LocalTime end = LocalTime.of(endHour, endMinute);
        LocalTime now = LocalTime.now();

        Log.w("Results:",startHour+":"+startMinute+" and "+endHour+":"+endMinute+" and "+ String.valueOf(now.isAfter(start) && now.isBefore(end)));

        return now.isAfter(start) && now.isBefore(end);
    }
}
