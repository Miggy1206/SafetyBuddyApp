package com.example.safetybuddyapp.Models;

import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Date;
import java.util.Map;

public class GroupRequests implements Constants{
    private String request_id;
    private Date request_date;
    private String request_group_id;
    private String request_status;

    public String getRequest_group_id() {
        return request_group_id;
    }

    public String getRequest_id() {
        return request_id;
    }

    public Date getRequest_date() {
        return request_date;
    }

    public String getRequest_status() {
        return request_status;
    }

    public void setRequest_group_id(String request_group_id) {
        this.request_group_id = request_group_id;
    }

    public void setRequest_id(String request_id) {
        this.request_id = request_id;
    }

    public void setRequest_date(Date request_date) {
        this.request_date = request_date;
    }

    public void setRequest_status(String request_status) {
        this.request_status = request_status;
    }

    public Task<DocumentSnapshot> get_specific_request(String user_id,String request_id){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .collection(REQUESTS_COLLECTION)
                .document(request_id)
                .get();
    }

    public Task<Void> create_group_join_request(String user_id, Map<String,Object> request){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .collection(REQUESTS_COLLECTION)
                .document(request.get("request_id").toString())
                .set(request);

    }
    public Task<Void> update_request(String user_id, String request_id, String request_status){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .collection(REQUESTS_COLLECTION)
                .document(request_id)
                .update("request_status",request_status);

    }

    public Task<QuerySnapshot> get_pending_requests_for_user(String user_id){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .collection(REQUESTS_COLLECTION)
                .whereEqualTo("request_status","pending")
                .get();
    }
    public Task<QuerySnapshot> get_accepted_requests_for_user(String user_id){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .collection(REQUESTS_COLLECTION)
                .whereEqualTo("request_status","accepted")
                .get();
    }
    public Task<QuerySnapshot> get_declined_requests_for_user(String user_id){
        return FirebaseFirestore.getInstance()
                .collection(USER_DATABASE)
                .document(user_id)
                .collection(REQUESTS_COLLECTION)
                .whereEqualTo("request_status","declined")
                .get();
    }
}

