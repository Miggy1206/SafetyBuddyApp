package com.example.safetybuddyapp.Fragments;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.example.safetybuddyapp.Adapters.GroupsAdapter;
import com.example.safetybuddyapp.Controllers.LocationController;
import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.Models.GeofenceHelper;
import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.Places;
import com.example.safetybuddyapp.Models.Reports;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.Views.ILocationView;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapColorScheme;
import com.google.android.gms.maps.model.MarkerOptions;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RequiresApi(api = Build.VERSION_CODES.Q)
public class LocationFragment extends Fragment implements Constants, ILocationView, OnMapReadyCallback {

    long update_frequency;
    boolean rule_applicable = true;
    Location current_location;
    private List<Group> groups_list;
    private String group_id;
    private User user;
    FusedLocationProviderClient fusedLocationProviderClient;
    SupportMapFragment mapFragment;
    private GoogleMap myMap;
    Dialog report_dialog, sos_dialog, stop_sos_dialog;
    LocationController locationController;
    View location_bottom_sheet;
    private GeofencingClient geofencingClient;
    private GeofenceHelper geofenceHelper;
    Button report_button,locations_button,sos_button, confirm_report_button, cancel_sos_button, stop_sos_button,close_sos_button, cancel_report_button;
    AutoCompleteTextView groups_textview;
    RadioGroup report_radio;
    RadioButton visibility_report,footfall_report,obstruction_report;
    MediaRecorder mediaRecorder;
    File file;
    ProgressBar sos_timer;
    int i;
    CountDownTimer mCountDownTimer;
    TextView security_code_input;
    TextInputLayout securityCodeLayout;
    private  LocationCallback locationCallback;

    String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    String COARSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    String BACKGROUND_LOCATION = Manifest.permission.ACCESS_BACKGROUND_LOCATION;
    int PERMISSION_GRANTED = PackageManager.PERMISSION_GRANTED;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_location, container, false);
        locationController = new LocationController(this);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getActivity());


        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    locationController.OnUpdateUserLocation(location);
                }
            }
        };

        report_button = view.findViewById(R.id.report_button);
        locations_button = view.findViewById(R.id.location_button);
        sos_button = view.findViewById(R.id.sos_button);
        groups_textview = view.findViewById(R.id.group_dropdown_textview);

        groups_textview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView id = view.findViewById(R.id.group_id_textview);
                group_id = id.getText().toString();
                locationController.OnUpdateDefaultGroup(group_id);
                myMap.clear();
                locationController.OnLoadGroupLocations(group_id);
                locationController.OnLoadGeofences();
                locationController.OnLoadGroupUsers(group_id);
                locationController.OnLoadReports();
            }
        });

        mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(LocationFragment.this);

        geofencingClient = LocationServices.getGeofencingClient(getActivity());
        geofenceHelper = new GeofenceHelper(getActivity());

        report_dialog = new Dialog(getActivity());
        report_dialog.setContentView(R.layout.location_report_dialog);
        report_dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        report_dialog.setCancelable(true);

        report_radio = report_dialog.findViewById(R.id.report_radio);
        confirm_report_button = report_dialog.findViewById(R.id.confirm_report_button);
        visibility_report = report_dialog.findViewById(R.id.visibility_report);
        visibility_report.setChecked(true);
        footfall_report = report_dialog.findViewById(R.id.footfall_report);
        obstruction_report = report_dialog.findViewById(R.id.obstruction_report);
        cancel_report_button = report_dialog.findViewById(R.id.cancel_report_button);


        sos_dialog = new Dialog(getActivity());
        sos_dialog.setContentView(R.layout.emergency_active_dialog);
        sos_dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        sos_dialog.setCancelable(false);

        cancel_sos_button = sos_dialog.findViewById(R.id.cancel_sos_button);
        sos_timer = sos_dialog.findViewById(R.id.sos_timer);


        stop_sos_dialog = new Dialog(getActivity());
        stop_sos_dialog.setContentView(R.layout.emergency_deactivate_dialog);
        stop_sos_dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        stop_sos_dialog.setCancelable(false);
        close_sos_button = stop_sos_dialog.findViewById(R.id.close_deactivate_button);
        stop_sos_button = stop_sos_dialog.findViewById(R.id.stop_emergency_button);
        security_code_input = stop_sos_dialog.findViewById(R.id.security_code_input);
        securityCodeLayout = stop_sos_dialog.findViewById(R.id.securityCodeLayout);



        stop_sos_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                locationController.OnStopEmergencyMode(security_code_input.getText().toString());
            }
        });


        cancel_report_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                report_dialog.hide();
            }
        });






        cancel_sos_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sos_dialog.hide();
                mCountDownTimer.cancel();
            }
        });





        report_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                report_dialog.show();

            }
        });

        confirm_report_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int report_reason = report_radio.getCheckedRadioButtonId();
                Log.w("Radio",report_reason+"");
                String reason = null;
                if(visibility_report.isChecked()){
                    reason = "poor_visibility";
                }
                else if(footfall_report.isChecked()){
                    reason = "low_footfall";

                }
                else if(obstruction_report.isChecked()){
                    reason = "obstruction";
                }
                locationController.OnCreateReport(reason,current_location);
            }
        });


        locations_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ManageLocationsFragment manageLocationsFragment = new ManageLocationsFragment();



                Bundle bundle = new Bundle();
                bundle.putString("GROUP_ID",group_id);
                manageLocationsFragment.setArguments(bundle);
                replaceFragment(manageLocationsFragment);
            }
        });


        sos_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!user.getEmergency_mode()) {
                    sos_dialog.show();
                    i = 0;

                    sos_timer.setProgress(i);
                    mCountDownTimer = new CountDownTimer(5000, 1000) {

                        @Override
                        public void onTick(long millisUntilFinished) {
                            i++;
                            sos_timer.setProgress((int) i * 100 / (5000 / 1000));

                        }

                        @Override
                        public void onFinish() {
                            sos_timer.setProgress(100);
                            locationController.OnToggleEmergencyMode(user);
                            try {
                                OnEmergencyButtonPressed();
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                            locationController.OnNotifyEmergency(user.getName(),0);
                            sos_dialog.hide();
                            locationController.OnLoadUserData();
                        }
                    };
                    mCountDownTimer.start();
                }else{
                    stop_sos_dialog.show();
                }
            }
        });





        return view;
    }


    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        myMap = googleMap;
        myMap.setTrafficEnabled(true);
        myMap.setMapColorScheme(MapColorScheme.DARK);

        locationController.OnLoadUserData();
        locationController.OnLoadGroups();
    }




    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void enableUserLocation() {
        if (ContextCompat.checkSelfPermission(getActivity(), FINE_LOCATION) == PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(getActivity(),COARSE_LOCATION) == PERMISSION_GRANTED) {
            if(ActivityCompat.checkSelfPermission(getActivity(), BACKGROUND_LOCATION) == PERMISSION_GRANTED){
                myMap.setMyLocationEnabled(false);
                if((user.isLocation_sharing() && rule_applicable) || user.getEmergency_mode() ) {
                    myMap.clear();
                    myMap.setMyLocationEnabled(true);
                    Task<Location> task = fusedLocationProviderClient.getLastLocation();
                    LocationRequest locationRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY)
                            .setIntervalMillis(update_frequency * 1000)
                            .setIntervalMillis(update_frequency *1000)
                                    .build();
                    fusedLocationProviderClient.requestLocationUpdates(locationRequest,locationCallback, Looper.getMainLooper());
                    task.addOnSuccessListener(new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {

                            current_location = location;

                            myMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), 18.0f));
                        }
                    });
                }
            }
            else{
                if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), BACKGROUND_LOCATION)) {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{BACKGROUND_LOCATION}, 101);
                } else {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{BACKGROUND_LOCATION}, 101);
                }
            }
        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), FINE_LOCATION)) {
                ActivityCompat.requestPermissions(getActivity(), new String[]{FINE_LOCATION,COARSE_LOCATION}, 101);
            } else {
                ActivityCompat.requestPermissions(getActivity(), new String[]{FINE_LOCATION,COARSE_LOCATION}, 101);
            }
        }
    }










    @Override
    public void OnGroupUsersLoaded(List<User> user_list) {
        for(User member:user_list) {
            if(member.getId().equals(FirebaseAuth.getInstance().getUid()) || !member.isLocation_sharing()) {

            }
            else{
                LatLng member_location = new LatLng(member.getCurrent_latitude(), member.getCurrent_longitude());
                myMap.addMarker(new MarkerOptions().position(member_location).title(member.getName()));
            }
        }
    }







    @Override
    public void OnGroupsLoaded(List<Group> group_list) {
        myMap.clear();
        if(group_id == null) {
            group_id = group_list.get(0).getGroup_id();
            locationController.OnUpdateDefaultGroup(group_id);
        }
        for(Group group: group_list){
            if(group.getGroup_id().equals(group_id)){
                groups_textview.setText(group.toString());
            }
        }

        GroupsAdapter adapter = new GroupsAdapter(getActivity(), group_list);
        groups_textview.setAdapter(adapter);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
        @Override
            public void run() {
            myMap.clear();
                locationController.OnLoadGroupLocations(group_id);
                locationController.OnLoadGeofences();
                locationController.OnLoadReports();
                locationController.OnLoadGroupUsers(group_id);
            handler.postDelayed(this, 15000);
        }
        },5000);
    }






    @Override
    public void OnLocationsLoaded(List<Places> places_list) {
        for(Places place:places_list) {
            LatLng places_coordinates = new LatLng(place.getLocation_latitude(),place.getLocation_longitude());
            MarkerOptions markerOptions = new MarkerOptions().position(places_coordinates);
            markerOptions.title(place.getLocation_name());

            markerOptions.icon(getCustomMarkerIcon());
            myMap.addMarker(markerOptions);

            CircleOptions circleOptions = new CircleOptions();
            circleOptions.center(places_coordinates);
            circleOptions.radius(20);
            circleOptions.strokeColor(Color.argb(255, 0, 0, 255));
            circleOptions.fillColor(Color.argb(64, 0, 0, 255));
            myMap.addCircle(circleOptions);
        }
    }

    @Override
    public void OnGeofencesLoaded(List<Places> geofence_list) {
        for(Places geofence: geofence_list) {
            LatLng places_coordinates = new LatLng(geofence.getLocation_latitude(),geofence.getLocation_longitude());
            addGeofence(geofence.getLocation_id(), places_coordinates, 20);
        }
    }

    @Override
    public void OnReportsLoaded(List<Reports> reports_list) {
        for(Reports reports : reports_list) {
            LatLng report_location = new LatLng(reports.getReport_latitude(),reports.getReport_longitude());
            CircleOptions circleOptions = new CircleOptions();
            circleOptions.center(report_location);
            circleOptions.radius(1);
            if(reports.getReport_type().equals("poor_visibility")) {
                circleOptions.strokeColor(POOR_VISIBILITY_COLOUR);
                circleOptions.fillColor(POOR_VISIBILITY_COLOUR);
            }
            else if(reports.getReport_type().equals("low_footfall")){
                circleOptions.strokeColor(LOW_FOOTFALL_COLOUR);
                circleOptions.fillColor(LOW_FOOTFALL_COLOUR);
            }
            else if(reports.getReport_type().equals("obstruction")){
                circleOptions.strokeColor(OBSTRUCTION_COLOUR);
                circleOptions.fillColor(OBSTRUCTION_COLOUR);
            }
            else{
                circleOptions.strokeColor(SOS_TOGGLED_COLOUR);
                circleOptions.fillColor(SOS_TOGGLED_COLOUR);
            }
            myMap.addCircle(circleOptions);
        }
    }

    @Override
    public void OnUserLoaded(User user) {
        this.user = user;
        if(user.getDefault_group() != null) {
            group_id = user.getDefault_group();
        }
        locationController.OnLoadRuleStatus(user.getId());
        update_frequency = user.getUpdate_frequency();
    }

    @Override
    public void OnRuleApplied(boolean rule_applicable) {
        this.rule_applicable = rule_applicable;
        enableUserLocation();
    }

    @Override
    public void OnEmergencyModeStopped() {
        stop_audio_recording();
        locationController.OnToggleEmergencyMode(user);
        stop_sos_dialog.hide();
        locationController.OnLoadUserData();
    }

    @Override
    public void OnEmergencyModeStoppedFake() {
        stop_sos_dialog.hide();


    }

    @Override
    public void OnInvalidSecurityCode() {
        securityCodeLayout.setError("Invalid Security Code!");
    }


    public void replaceFragment(Fragment fragment){
        getActivity().getSupportFragmentManager().
                beginTransaction().
                replace(R.id.frame_layout, fragment).
                setReorderingAllowed(true).
                addToBackStack(null).commit();
    }


    private BitmapDescriptor getCustomMarkerIcon() {
        @SuppressLint("UseCompatLoadingForDrawables") Drawable drawable1 = getResources().getDrawable(R.drawable.baseline_how_to_reg_24);
        Bitmap profileBitmap = Bitmap.createBitmap(drawable1.getIntrinsicWidth(),
                drawable1.getIntrinsicHeight(),
                Bitmap.Config.ARGB_8888);

        Bitmap bitmap = Bitmap.createScaledBitmap(profileBitmap,30,30,false);

        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }




    private void OnEmergencyButtonPressed() throws InterruptedException {
        update_frequency = 1;
        locationController.OnCreateReport("sos_emergency",current_location);
        start_audio_recording();
    }



    private void addGeofence(String place_id, LatLng latLng, float radius) {
        Geofence geofence = geofenceHelper.getGeofence(place_id, latLng, radius, Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT | Geofence.GEOFENCE_TRANSITION_DWELL);

        GeofencingRequest geofencingRequest = geofenceHelper.getGeofencingRequest(geofence);
        PendingIntent pendingIntent = geofenceHelper.getPendingIntent();
        geofencingClient.addGeofences(geofencingRequest, pendingIntent)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Log.w("Geofence added", "Geofence added");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        String error = geofenceHelper.getErrorString(e);
                        Log.w("Geofence failed", error);
                    }
                });
    }








    private void start_audio_recording(){
        if(ActivityCompat.checkSelfPermission(getActivity(),Manifest.permission.RECORD_AUDIO) == PERMISSION_GRANTED){

            file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),FirebaseAuth.getInstance().getUid()+"-"+new Date().toString().replace(" ","-").replace("+","-").replace(":","-")+".mp4");
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mediaRecorder.setOutputFile(file.getAbsolutePath());


            try{
                mediaRecorder.prepare();
                mediaRecorder.start();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        else{
            ActivityCompat.requestPermissions(getActivity(),new String[]{
                    Manifest.permission.RECORD_AUDIO
            },1);
        }

    }

    private void stop_audio_recording() {

        if (mediaRecorder != null) {
            mediaRecorder.stop();
            mediaRecorder.release();


            Uri audioFileUri = Uri.fromFile(file.getAbsoluteFile()); // Example path

            FirebaseStorage storage = FirebaseStorage.getInstance();
            StorageReference storageRef = storage.getReference();
            StorageReference audioRef = storageRef.child("audio/" + audioFileUri.getLastPathSegment());

            UploadTask uploadTask = audioRef.putFile(audioFileUri);

            uploadTask.addOnSuccessListener(taskSnapshot -> {
                audioRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    String downloadUrl = uri.toString();
                    file.delete();
                    Log.d("Firebase", "Upload successful. URL: " + downloadUrl);
                });
            }).addOnFailureListener(e -> {
                Log.e("Firebase", "Upload failed", e);
            });
        }
    }

}