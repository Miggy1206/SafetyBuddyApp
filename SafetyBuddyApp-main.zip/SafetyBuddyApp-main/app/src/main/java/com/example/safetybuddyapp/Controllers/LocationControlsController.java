package com.example.safetybuddyapp.Controllers;

import com.example.safetybuddyapp.Models.LocationRules;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.Views.ILocationControlsView;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LocationControlsController {
    private ILocationControlsView locationControlsView;
    private LocationRules locationRules;
    private User user;
    private boolean new_location_status;

    public LocationControlsController(ILocationControlsView locationControlsView){
        this.locationControlsView = locationControlsView;
    }

    public void OnLoadLocationSettings(){
        locationRules = new LocationRules();
        locationRules.get_rule(FirebaseAuth.getInstance().getUid()).addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if(documentSnapshot.exists()){
                    locationControlsView.OnRuleLoaded(documentSnapshot.toObject(LocationRules.class));
                }
            }
        });

    }

    public void OnUpdateTimeBasedRule(String start_date,String end_date){
        locationRules = new LocationRules();
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm", Locale.getDefault());


        Date start = null;
        Date end = null;
        try {
            start =formatter.parse(start_date);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        try {
            end = formatter.parse(end_date);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        locationRules.setRule_id(FirebaseAuth.getInstance().getUid());
        locationRules.setStart_time(start);
        locationRules.setEnd_time(end);
        locationRules.create_rule(FirebaseAuth.getInstance().getUid());


    }

    public void OnDeleteRule(String user_id){
        locationRules = new LocationRules();

        locationRules.delete_rule(user_id).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

            }
        });
    }


    public void OnLocationStatusLoaded(){
        user = new User();
        Task<DocumentSnapshot> user_response = user.get_individual_user(FirebaseAuth.getInstance().getUid());
        user_response.addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                user = documentSnapshot.toObject(User.class);
                locationControlsView.OnLocationStatusLoaded(user);
            }
        });
    }

    public void OnToggleLocation() {
        user = new User();

        Task<DocumentSnapshot> user_response = user.get_individual_user(FirebaseAuth.getInstance().getUid());
        user_response.addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                user = documentSnapshot.toObject(User.class);
                new_location_status = user.isLocation_sharing();
                if (new_location_status) {
                    new_location_status = false;
                } else {
                    new_location_status = true;
                }
                user.update_location_status(FirebaseAuth.getInstance().getUid(), new_location_status).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        locationControlsView.OnLocationToggled(new_location_status);
                    }
                });
            }
        });
    }

    public void OnUpdateFrequency(int frequency){
        user = new User();

        user.update_frequency(FirebaseAuth.getInstance().getUid(), frequency).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

            }
        });
    }
}
