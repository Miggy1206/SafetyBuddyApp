package com.example.safetybuddyapp.Fragments;

import android.app.Dialog;
import android.location.Address;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.safetybuddyapp.Adapters.PlacesAdapter;
import com.example.safetybuddyapp.Controllers.ManageLocationsController;
import com.example.safetybuddyapp.Models.Places;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.Views.IManageLocationsView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.textfield.TextInputLayout;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ManageLocationsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ManageLocationsFragment extends Fragment implements IManageLocationsView {

    private Address address = null;
    private String group_id;
    Button locations_back_button, add_location_button;
    BottomSheetDialog add_location_sheet;
    ManageLocationsController manageLocationsController;
    TextView address_output;
    Button address_search_button, confirm_add_address_button;
    TextView address_textview, location_name_textview;
    TextInputLayout addressSearchLayout, locationNameLayout;
    ListView places_list;
    Dialog delete_location_dialog;
    Button cancel_button, confirm_delete_button;
    String place_id_string;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_manage_locations, container, false);
        locations_back_button = view.findViewById(R.id.locations_back_button);
        add_location_button = view.findViewById(R.id.add_location_button);
        places_list = view.findViewById(R.id.places_list);

        manageLocationsController = new ManageLocationsController(this);
        group_id =getArguments().getString("GROUP_ID");

        manageLocationsController.OnLoadPlaces(group_id);




        delete_location_dialog = new Dialog(getActivity());
        delete_location_dialog.setContentView(R.layout.delete_location_dialog);
        delete_location_dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        delete_location_dialog.setCancelable(true);
        cancel_button = delete_location_dialog.findViewById(R.id.cancel_button);
        confirm_delete_button =delete_location_dialog.findViewById(R.id.confirm_delete_button);


        places_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView place_id = view.findViewById(R.id.place_id_textview);
                place_id_string = place_id.getText().toString();
                delete_location_dialog.show();

            }
        });

        confirm_delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                manageLocationsController.OnDeleteLocation(group_id,place_id_string);
            }
        });

        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delete_location_dialog.hide();
            }
        });


        locations_back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getParentFragmentManager().popBackStack();
            }
        });

        add_location_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add_location_sheet = new BottomSheetDialog(getActivity());
                View view1 = LayoutInflater.from(getActivity()).inflate(R.layout.bottom_sheet_add_location_layout,null);
                add_location_sheet.setContentView(view1);
                add_location_sheet.show();
                location_name_textview = view1.findViewById(R.id.location_name_textview);
                address_search_button = view1.findViewById(R.id.confirm_address_search);
                address_textview = view1.findViewById(R.id.address_search);
                address_output = view1.findViewById(R.id.address_choice);
                confirm_add_address_button = view1.findViewById(R.id.confirm_add_location_button);

                addressSearchLayout = view1.findViewById(R.id.addressSearchLayout);

                address_search_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        addressSearchLayout.setErrorEnabled(false);
                        address_output.setText(null);
                        address = null;
                        manageLocationsController.OnSearchAddress(getActivity(),address_textview.getText().toString());
                    }
                });
                confirm_add_address_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        manageLocationsController.OnAddLocation(group_id,
                                location_name_textview.getText().toString(),address);
                    }
                });

            }
        });
        return view;
    }

    @Override
    public void OnAddressFound(Address address) {
        this.address = address;
        address_output.setText(address.getAddressLine(0));
    }

    @Override
    public void OnPlacesLoaded(List<Places> places) {
        PlacesAdapter placesAdapter = new PlacesAdapter(getContext(),places);
        places_list.setAdapter(placesAdapter);
    }

    @Override
    public void OnInvalidAddress() {
        addressSearchLayout.setError("The address entered is invalid!");
    }

    @Override
    public void OnAddressNotFound() {
        addressSearchLayout.setError("No valid address was found!");
    }

    @Override
    public void OnLocationDeleted() {
        delete_location_dialog.hide();
        manageLocationsController.OnLoadPlaces(group_id);
    }
}