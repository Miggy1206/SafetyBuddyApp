package com.example.safetybuddyapp.Models;

import android.content.pm.PackageManager;
import android.util.Log;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.text.util.LocalePreferences;

import com.example.safetybuddyapp.R;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Properties;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class FirebaseInstanceService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // Handle FCM message
        if (!remoteMessage.getData().isEmpty()) {
            Log.d("FCM Message", "Message data payload: " +
                    remoteMessage.getData());
        }
        if (remoteMessage.getNotification() != null) {
            Log.d("FCM Message", "Message Notification Body: " +
                    remoteMessage.getNotification().getBody());
            handleNotification(remoteMessage);
        }
    }


    public void onMessageSent(String token, String user_name, String title, String body) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                MediaType mediaType = MediaType.parse("application/json");
                JSONObject jsonNotif = new JSONObject();
                JSONObject wholeObj = new JSONObject();

                try {
                    jsonNotif.put("title", title); // Customize title
                    jsonNotif.put("body", body); // Custom body
                    wholeObj.put("message", new JSONObject()
                            .put("token", token)
                            .put("notification", jsonNotif));

                } catch (JSONException e) {
                    e.printStackTrace();
                    return;
                }

                RequestBody requestBody = RequestBody.create(mediaType, wholeObj.toString());

                Request request = null;
                request = new Request.Builder()
                        .url("https://fcm.googleapis.com/v1/projects/fyp-final-ba858/messages:send")
                        .post(requestBody)
                        .addHeader("Authorization", "Bearer ")
                        .addHeader("Content-Type", "application/json")
                        .build();

                try {
                    Response response = client.newCall(request).execute();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }




    private void handleNotification(RemoteMessage remoteMessage) {
        NotificationCompat.Builder builder = new
                NotificationCompat.Builder(this, "firebase")
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle(remoteMessage.getNotification().getTitle())
                .setContentText(remoteMessage.getNotification().getBody())
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        NotificationManagerCompat notificationManager =
                NotificationManagerCompat.from(this);

        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED) {
            return;
        }
        notificationManager.notify(1, builder.build());
    }
}
