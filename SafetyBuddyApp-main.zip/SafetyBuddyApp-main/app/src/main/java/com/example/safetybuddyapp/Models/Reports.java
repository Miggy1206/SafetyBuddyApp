package com.example.safetybuddyapp.Models;

import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Calendar;
import java.util.Date;

public class Reports implements Constants{
    private String report_id;
    private String report_type;
    private Date report_date;
    private double report_latitude;
    private double report_longitude;

    public Reports(){

    }

    public String getReport_id() {
        return report_id;
    }

    public Date getReport_date() {
        return report_date;
    }

    public double getReport_latitude() {
        return report_latitude;
    }

    public double getReport_longitude() {
        return report_longitude;
    }

    public String getReport_type() {
        return report_type;
    }

    public void setReport_id(String report_id) {
        this.report_id = report_id;
    }

    public void setReport_date(Date report_date) {
        this.report_date = report_date;
    }

    public void setReport_latitude(double report_latitude) {
        this.report_latitude = report_latitude;
    }

    public void setReport_longitude(double report_longitude) {
        this.report_longitude = report_longitude;
    }

    public void setReport_type(String report_type) {
        this.report_type = report_type;
    }

    public Task<Void> create_report(){
        return FirebaseFirestore.getInstance()
                .collection(REPORTS_DATABASE)
                .document(this.report_id)
                .set(this);
    }

    public Task<QuerySnapshot> load_user_reports(){
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE,-7);
        return FirebaseFirestore.getInstance()
                .collection(REPORTS_DATABASE)
                .whereGreaterThanOrEqualTo("report_date",c.getTime())
                .get();
    }
}
