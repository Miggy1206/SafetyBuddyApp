package com.example.safetybuddyapp.Views;

import android.graphics.Bitmap;

import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.User;

import java.util.List;

public interface IManageGroupsView {
    void OnGroupLoaded(Group group);
    void OnMembersLoaded(List<User> user_list);
    void OnFriendsAvailableLoaded(List<User> user_list);
    void OnCoverImageLoaded(Bitmap cover_image);
}
