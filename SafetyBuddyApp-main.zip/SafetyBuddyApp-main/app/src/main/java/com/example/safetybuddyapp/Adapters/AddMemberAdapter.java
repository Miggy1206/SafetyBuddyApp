package com.example.safetybuddyapp.Adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.GroupRequests;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class AddMemberAdapter extends ArrayAdapter<User> {
    private Group group;
    public AddMemberAdapter(Context context, List<User> user_list, Group group) {
        super(context, 0, user_list);
        this.group = group;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.add_member_rows_layout,parent,false);
        }
        User user = getItem(position);
        ImageView user_profile_imageview = convertView.findViewById(R.id.user_profile_image);
        TextView user_email_textview = convertView.findViewById(R.id.user_email_textview);
        TextView user_id_textview = convertView.findViewById(R.id.user_id_textview);
        TextView user_name_textview = convertView.findViewById(R.id.user_name_textview);
        Button send_group_request = convertView.findViewById(R.id.send_request_button);

        if(user != null){
            StorageReference storageReference = FirebaseStorage.getInstance().getReference();
            StorageReference photoReference= storageReference.child(user.getProfile_image_link());

            final long ONE_MEGABYTE = 1024 * 1024 * 5;
            photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                @Override
                public void onSuccess(byte[] bytes) {
                    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    user_profile_imageview.setImageBitmap(bmp);

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    user_profile_imageview.setImageBitmap(null);
                }
            });
            user_email_textview.setText(user.getEmail());
            user_name_textview.setText(user.getName());
            user_id_textview.setText(user.getId());
            send_group_request.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    GroupRequests new_requests = new GroupRequests();
                    Map<String,Object> request = new HashMap<>();
                    request.put("request_id",UUID.randomUUID().toString());
                    request.put("request_date",new Date());
                    request.put("request_group_id",group.getGroup_id());
                    request.put("request_status","pending");

                    new_requests.create_group_join_request(user_id_textview.getText().toString(), request );
                }
            });
        }

        return convertView;
    }
}
