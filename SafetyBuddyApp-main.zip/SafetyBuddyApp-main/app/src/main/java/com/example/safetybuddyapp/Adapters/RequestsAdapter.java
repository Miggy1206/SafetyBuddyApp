package com.example.safetybuddyapp.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.GroupRequests;
import com.example.safetybuddyapp.R;

import java.util.Date;
import java.util.List;

public class RequestsAdapter extends ArrayAdapter<GroupRequests> {

    public RequestsAdapter(Context context, List<GroupRequests> groupRequestsList) {
        super(context, 0,groupRequestsList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.group_requests_rows_layout,parent,false);
        }


        GroupRequests request = getItem(position);
        TextView request_id_textview = convertView.findViewById(R.id.request_id_textview);
        TextView request_date_textview = convertView.findViewById(R.id.request_date_textview);
        TextView request_group_id_textview = convertView.findViewById(R.id.request_group_id_textview);
        TextView request_status_textview = convertView.findViewById(R.id.request_status_textview);

        if(request != null){
            request_id_textview.setText(request.getRequest_id());
            request_date_textview.setText(new StringBuilder().append("Date Requested:").append(request.getRequest_date().toString()).toString());
            request_group_id_textview.setText(new StringBuilder().append("Group ID:").append(request.getRequest_group_id()).toString());
            request_status_textview.setText(request.getRequest_status());
        }

        return convertView;
    }
}
