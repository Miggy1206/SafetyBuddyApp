package com.example.safetybuddyapp.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.safetybuddyapp.Controllers.CodesController;
import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.Views.ICodesView;
import com.google.android.material.textfield.TextInputLayout;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CodesFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CodesFragment extends Fragment implements ICodesView, Constants {

    private TextView security_code_input_textview, false_security_code_input_textview, saved_codes_confirmation;
    private TextInputLayout securityCodeInputLayout, falseSecurityCodeInputLayout;
    private Button save_codes_button, codes_back_button;
    private User user;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_codes, container, false);

        CodesController codesController = new CodesController(this);

        security_code_input_textview = view.findViewById(R.id.security_code_input);
        false_security_code_input_textview = view.findViewById(R.id.fake_security_code_input);
        saved_codes_confirmation = view.findViewById(R.id.saved_codes_confirmation);

        securityCodeInputLayout = view.findViewById(R.id.securityCodeInputLayout);
        falseSecurityCodeInputLayout = view.findViewById(R.id.falseSecurityCodeInputLayout);

        save_codes_button = view.findViewById(R.id.save_security_codes_button);
        codes_back_button = view.findViewById(R.id.codes_back_button);

        codesController.OnLoadCodes();


        security_code_input_textview.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                saved_codes_confirmation.setText(null);
                securityCodeInputLayout.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        false_security_code_input_textview.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                saved_codes_confirmation.setText(null);
                falseSecurityCodeInputLayout.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        save_codes_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saved_codes_confirmation.setText(null);
                securityCodeInputLayout.setErrorEnabled(false);
                falseSecurityCodeInputLayout.setErrorEnabled(false);
                if(user.getEmergency_mode()){
                    securityCodeInputLayout.setError("Codes can not be changed during emergencies!");
                    falseSecurityCodeInputLayout.setError("Codes can not be changed during emergencies!");
                }
                else {
                    codesController.OnSaveCodes(
                            security_code_input_textview.getText().toString(),
                            false_security_code_input_textview.getText().toString()
                    );
                }
            }
        });

        codes_back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getParentFragmentManager().popBackStack();
            }
        });



        return view;
    }

    @Override
    public void OnCodesLoaded(User user) {
        this.user = user;
        security_code_input_textview.setText(user.getSecurity_code());
        false_security_code_input_textview.setText(user.getFalse_security_code());
    }

    @Override
    public void OnCodesSaved() {
        saved_codes_confirmation.setText("Saved✔");
    }

    @Override
    public void OnSecurityCodeInvalid(int decline_code) {
        switch(decline_code){
            case EMPTY_FIELD:
                securityCodeInputLayout.setError("Field can not be empty!");
                break;
            case INVALID_FORMAT:
                securityCodeInputLayout.setError("Field must have exactly 4 numbers");
                break;
        }
    }

    @Override
    public void OnFalseSecurityCodeInvalid(int decline_code) {
        switch(decline_code){
            case EMPTY_FIELD:
                falseSecurityCodeInputLayout.setError("Field can not be empty!");
                break;
            case INVALID_FORMAT:
                falseSecurityCodeInputLayout.setError("Field must have exactly 4 numbers");
                break;
        }
    }

    @Override
    public void OnMatchingCodes() {
        securityCodeInputLayout.setError("Codes can not match!");
        falseSecurityCodeInputLayout.setError("Codes can not match!");
    }


}