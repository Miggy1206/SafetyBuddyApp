package com.example.safetybuddyapp.Controllers;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.Places;
import com.example.safetybuddyapp.Views.IManageLocationsView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firestore.admin.v1.Index;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ManageLocationsController {
    private IManageLocationsView manageLocationsView;
    private Places location;
    public ManageLocationsController(IManageLocationsView manageLocationsView){this.manageLocationsView = manageLocationsView;}

    public void OnLoadPlaces(String group_id){
        location = new Places();


        Task<QuerySnapshot> places_result = location.get_places_for_group(group_id);

        places_result.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful() && !task.getResult().isEmpty()){
                    manageLocationsView.OnPlacesLoaded(task.getResult().toObjects(Places.class));
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
    }

    public void OnSearchAddress(Context context, String address){
        Geocoder geocoder = new Geocoder(context);
        List<Address> response = null;
        try {
            response = geocoder.getFromLocationName(address, 10);
            if(!response.isEmpty()) {
                manageLocationsView.OnAddressFound(response.get(0));
            }
            else{
                manageLocationsView.OnAddressNotFound();
            }
        } catch (IOException e) {
            manageLocationsView.OnInvalidAddress();
        }


    }

    public void OnAddLocation(String group_id, String location_name, Address address){
        location = new Places();
        location.setLocation_id(UUID.randomUUID().toString());
        location.setLocation_name(location_name);
        location.setLocation_address(address.getAddressLine(0));
        location.setLocation_latitude(address.getLatitude());
        location.setLocation_longitude(address.getLongitude());
        location.add_place(group_id);

    }

    public void OnDeleteLocation(String group_id,String place_id){
        location = new Places();
        Task<Void> place_response = location.delete_location(group_id,place_id);
        place_response.addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                manageLocationsView.OnLocationDeleted();
            }
        });
    }
}
