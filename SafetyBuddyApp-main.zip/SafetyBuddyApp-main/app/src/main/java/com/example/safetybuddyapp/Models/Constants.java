package com.example.safetybuddyapp.Models;

import android.graphics.Color;

import com.example.safetybuddyapp.R;

public interface Constants {

    //Firestore database variables
    String USER_DATABASE = "USERS";
    String GROUP_DATABASE = "GROUPS";
    String REPORTS_DATABASE = "REPORTS";
    String REQUESTS_COLLECTION = "REQUESTS";
    String LOCATION_COLLECTION = "LOCATIONS";
    String RULES_COLLECTION = "RULES";


    //Decline codes
    int VALID_FORMAT = 0;
    int EMPTY_FIELD = 1;
    int INVALID_FORMAT = 2;
    int UNVERIFIED_FIELD = 3;
    int ILLOGICAL_FIELD = 4;
    int AGAINST_T_AND_TS = 5;
    int MATCHING_FIELDS = 6;
    int NOT_MATCHING_FIELDS = 7;
    int ALREADY_IN_USE = 8;
    int AGE_REQUIREMENT = 10; //10 YEARS OLD

    //Error messages displayed to UI
    String INVALID_LOGIN_DETAILS_ERROR = "Email and/or Password are incorrect!";
    String FIREBASE_CONNECTION_ERROR = "Could not connect to server!";

    String EMAIL_IN_USE_ERROR ="An account with this email already exists!";
    String EMAIL_NOT_VERIFIED_ERROR = "The email has not been verified yet!";
    String EMAIL_INVALID_FORMAT_ERROR = "The inserted email is not valid!";
    String EMAIL_EMPTY_FIELD_ERROR = "The email field must not be empty!";

    String NAME_EMPTY_FIELD_ERROR = "The name field must not be empty!";

    String PHONE_NUMBER_EMPTY_FIELD_ERROR = "The phone number field must not be empty!";
    String PHONE_NUMBER_INVALID_FORMAT_ERROR = "The inserted phone number is not valid!";

    String BIRTH_EMPTY_FIELD_ERROR = "The date of birth field must not be empty!";
    String BIRTH_ILLOGICAL_FIELD_ERROR = "Date of birth can not occur in the future!";
    String BIRTH_T_AND_TS_ERROR = "A minimum age of "+AGE_REQUIREMENT+" years old is required!";





    String PASSWORD_INVALID_FORMAT_ERROR = "The inserted password is not valid!";
    String PASSWORD_EMPTY_FIELD_MESSAGE = "The password field must not be empty!";
    String NOT_MATCHING_PASSWORDS_ERROR = "The passwords do not match!";



    int POOR_VISIBILITY_COLOUR = Color.argb(255,0,0,0);
    int OBSTRUCTION_COLOUR = Color.argb(255,255,255,0);
    int LOW_FOOTFALL_COLOUR = Color.argb(255,0,0,255);
    int SOS_TOGGLED_COLOUR = Color.argb(255,255,0,0);



    int EMERGENCY_MODE_ACTIVATED = 0;
    int EMERGENCY_MODE_DEACTIVATED = 1;
    int EMERGENCY_MODE_COERCION_MODE = 2;

}
