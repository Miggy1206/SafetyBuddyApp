package com.example.safetybuddyapp.Views;

import com.example.safetybuddyapp.Models.User;

public interface ICodesView {
    void OnCodesLoaded(User user);
    void OnCodesSaved();
    void OnSecurityCodeInvalid(int decline_code);
    void OnFalseSecurityCodeInvalid(int decline_code);
    void OnMatchingCodes();
}
