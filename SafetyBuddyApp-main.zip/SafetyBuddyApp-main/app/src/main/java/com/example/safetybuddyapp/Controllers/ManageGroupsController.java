package com.example.safetybuddyapp.Controllers;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.Views.IManageGroupsView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class ManageGroupsController {
    private IManageGroupsView manageGroupsView;
    Group group;
    User user;

    public ManageGroupsController(IManageGroupsView manageGroupsView){this.manageGroupsView = manageGroupsView;}

    public void OnLoadGroup(String group_id){
        group = new Group();

        Task<DocumentSnapshot> group_result = group.get_single_group(group_id);

        group_result.addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                Group group_get = documentSnapshot.toObject(Group.class);
                manageGroupsView.OnGroupLoaded(group_get);
                OnLoadMemberList(group_get.getGroup_members());
                OnLoadFriendsAvailable(group_get.getGroup_members());
                OnLoadCoverImage(group_get);
            }
        });
    }

    public void OnLoadMemberList(List<String> group_members){

        user = new User();

        Task<QuerySnapshot> users_result = user.get_users_for_group(group_members);

        users_result.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()){
                    List<User> user_list = task.getResult().toObjects(User.class);
                    manageGroupsView.OnMembersLoaded(user_list);
                }
            }
        });


    }

    public void OnLoadFriendsAvailable(List<String> user_list){
        user = new User();

        Task<QuerySnapshot> users_result = user.get_users_not_in_group(user_list);

        users_result.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()){
                    List<User> user_list = task.getResult().toObjects(User.class);
                    manageGroupsView.OnFriendsAvailableLoaded(user_list);
                }
            }
        });
    }
    public void OnLeaveGroup(Group group){
        if(group.getGroup_members().size() == 1){
            group.delete_group(group.getGroup_id());
        }
        else{
            Task<Void> group_response = group.delete_member(group.getGroup_id(), FirebaseAuth.getInstance().getUid());
            group_response.addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    if(group.getGroup_members().get(0).equals(FirebaseAuth.getInstance().getUid())){
                        OnChangeAdmin(group.getGroup_members().get(1),group.getGroup_id());
                    }
                    else{
                        OnChangeAdmin(group.getGroup_members().get(0),group.getGroup_id());
                    }

                }
            });
        }

    }

    public void OnChangeAdmin(String user_id, String group_id){
        group = new Group();
        group.change_admin(group_id,user_id).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

            }
        });

    }

    public void OnRemoveMember(String user_id, Group group){
        Task<Void>  group_response = group.delete_member(group.getGroup_id(),user_id);
        group_response.addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

            }
        });
    }





    public void OnLoadCoverImage(Group group){
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference photoReference= storageReference.child(group.getGroup_profile_image());

        final long ONE_MEGABYTE = 1024 * 1024 * 5;
        photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                manageGroupsView.OnCoverImageLoaded(bmp);

            }
        });
    }
    public void OnUpdateCoverImage(Group group, Bitmap new_profile_image){

        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference photoReference= storageReference.child("pictures/"+group.getGroup_id());

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        new_profile_image.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        photoReference.putBytes(data).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                group.update_cover_image(group.getGroup_id(),"pictures/"+group.getGroup_id());
            }
        });
    }
}
