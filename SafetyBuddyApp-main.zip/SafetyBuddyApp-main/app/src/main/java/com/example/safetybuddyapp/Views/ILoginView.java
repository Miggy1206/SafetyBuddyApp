package com.example.safetybuddyapp.Views;

public interface ILoginView {
    void OnLoginSuccess();
    void OnLoginError(String error_message);
    void OnInvalidEmail(int decline_code);
    void OnInvalidPassword(int decline_code);
}
