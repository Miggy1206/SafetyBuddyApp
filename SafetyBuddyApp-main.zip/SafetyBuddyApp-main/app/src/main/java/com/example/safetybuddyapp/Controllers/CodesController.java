package com.example.safetybuddyapp.Controllers;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.Views.ICodesView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;

public class CodesController implements Constants {
    private ICodesView codesView;
    private User user;

    public CodesController(ICodesView codesView){this.codesView = codesView;}

    public void OnLoadCodes(){
        user = new User();
        Task<DocumentSnapshot> user_response = user.get_individual_user(FirebaseAuth.getInstance().getUid());

        user_response.addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                user = documentSnapshot.toObject(User.class);
                codesView.OnCodesLoaded(user);
            }
        });
    }

    public void OnSaveCodes(String security_code, String false_security_code){
        user = new User();

        int security_validity = user.is_valid_security_code(security_code);
        int false_security_validity = user.is_valid_security_code(false_security_code);
        boolean matching_codes = user.is_matching_codes(security_code,false_security_code);

        if(matching_codes){
            codesView.OnMatchingCodes();
        }
        if(security_validity != VALID_FORMAT){
            codesView.OnSecurityCodeInvalid(security_validity);
        }
        if(false_security_validity != VALID_FORMAT){
            codesView.OnFalseSecurityCodeInvalid(false_security_validity);
        }

        if(security_validity == VALID_FORMAT && false_security_validity == VALID_FORMAT && !matching_codes) {

            Task<Void> update_response = user.update_security_codes(FirebaseAuth.getInstance().getUid(), security_code, false_security_code);

            update_response.addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    codesView.OnCodesSaved();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });
        }

    }
}
