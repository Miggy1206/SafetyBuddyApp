package com.example.safetybuddyapp.Views;

import android.graphics.Bitmap;

import com.example.safetybuddyapp.Models.User;

public interface IProfileView {
    void OnUserLoaded(User user);
    void OnProfileImageLoaded(Bitmap profile_image);
    void OnInvalidName(int decline_code);
    void OnInvalidNumber(int decline_code);
    void OnSaveSuccess();
}
