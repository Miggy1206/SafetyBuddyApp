package com.example.safetybuddyapp.Controllers;

import android.util.Log;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Views.IGroupsView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class GroupsController implements Constants{
    private IGroupsView groupsView;
    private Group group;

    public GroupsController(IGroupsView groupsView){this.groupsView = groupsView;}


    public void OnLoadGroups() {
        String user_id = FirebaseAuth.getInstance().getUid();
        group = new Group();
        Task<QuerySnapshot> groups_for_user = group.get_groups_for_user(user_id);

        groups_for_user.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    List<Group> group_list = task.getResult().toObjects(Group.class);
                    groupsView.OnGroupsLoaded(group_list);

                }
            }
        });

    }

    public void OnAddGroup(String group_name) {

        String group_id = UUID.randomUUID().toString();
        group = new Group();
        List<String> members = new ArrayList<>();
        Map<String,Object> group_instance = new HashMap<>();
        members.add(FirebaseAuth.getInstance().getUid());


        group_instance.put("group_id",group_id);
        group_instance.put("group_name",group_name);
        group_instance.put("group_admin",FirebaseAuth.getInstance().getUid());
        group_instance.put("group_members",members);
        group_instance.put("group_profile_image","pictures/default_profile.png");


        group.add_group(group_instance).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                groupsView.OnGroupAddedSuccessful();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                groupsView.OnGroupAddedError();
            }
        });


    }
}
