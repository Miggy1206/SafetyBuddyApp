package com.example.safetybuddyapp.Controllers;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.Views.IProfileView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;

public class ProfileController implements Constants {
    private IProfileView profileView;
    private User user;

    public ProfileController(IProfileView profileView){
        this.profileView = profileView;
    }
    public void OnLoadUser(){
        user = new User();
        Task<DocumentSnapshot> user_response = user.get_individual_user(FirebaseAuth.getInstance().getUid());
        user_response.addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                user = documentSnapshot.toObject(User.class);
                profileView.OnUserLoaded(user);
                OnLoadProfileImage(user);
            }
        });


    }

    public void OnLoadProfileImage(User user){
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference photoReference= storageReference.child(user.getProfile_image_link());

        final long ONE_MEGABYTE = 1024 * 1024 * 5;
        photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                profileView.OnProfileImageLoaded(bmp);

            }
        });
    }
    public void OnUpdateProfileImage(Bitmap new_profile_image){
        user= new User();

        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference photoReference= storageReference.child("pictures/"+FirebaseAuth.getInstance().getUid());

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        new_profile_image.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        photoReference.putBytes(data).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                user.update_profile_image(FirebaseAuth.getInstance().getUid(),"pictures/"+FirebaseAuth.getInstance().getUid());
            }
        });
    }

    public void OnSaveProfileDetails(String name,String phone_number){
        user = new User();
        int name_code = user.is_valid_name(name);
        int phone_code = user.is_valid_phone_number(phone_number);
        if(name_code != VALID_FORMAT){
            profileView.OnInvalidName(name_code);
        }
        if(phone_code != VALID_FORMAT){
            profileView.OnInvalidNumber(phone_code);
        }
        if(name_code == VALID_FORMAT && phone_code == VALID_FORMAT) {
            Task<Void> user_response = user.update_profile_details(FirebaseAuth.getInstance().getUid(), name, phone_number);
            user_response.addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    profileView.OnSaveSuccess();
                }
            });
        }
    }
}
