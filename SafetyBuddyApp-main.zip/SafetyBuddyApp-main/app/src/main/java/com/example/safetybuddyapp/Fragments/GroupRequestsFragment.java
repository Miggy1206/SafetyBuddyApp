package com.example.safetybuddyapp.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.safetybuddyapp.Adapters.GroupsAdapter;
import com.example.safetybuddyapp.Adapters.RequestsAdapter;
import com.example.safetybuddyapp.Controllers.GroupRequestController;
import com.example.safetybuddyapp.Models.GroupRequests;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.Views.IGroupRequestsView;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;


public class GroupRequestsFragment extends Fragment implements IGroupRequestsView {


    private List<GroupRequests> requests = new ArrayList<>();

    private ListView requests_list;
    private TabLayout requests_tabs;
    private Button group_requests_back_button;
    private int tab_option;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_group_requests, container, false);

        GroupRequestController groupRequestController = new GroupRequestController(this);
        requests = new ArrayList<>();

        requests_list = view.findViewById(R.id.requests_list);
        requests_tabs = view.findViewById(R.id.group_request_tabs);
        group_requests_back_button = view.findViewById(R.id.group_requests_back_button);

        groupRequestController.OnLoadPendingRequests();
        tab_option = 0;

        group_requests_back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getParentFragmentManager().popBackStack();
            }
        });

        requests_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(tab_option == 0) {
                    TextView request_id = view.findViewById(R.id.request_id_textview);
                    Bundle bundle = new Bundle();
                    ManageRequestFragment manageRequestFragment = new ManageRequestFragment();
                    bundle.putString("REQUEST_ID", request_id.getText().toString());
                    manageRequestFragment.setArguments(bundle);

                    replaceFragment(manageRequestFragment);
                }


            }
        });

        requests_tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch(tab.getPosition()){
                    case 0:
                        groupRequestController.OnLoadPendingRequests();
                        tab_option = 0;
                        break;
                    case 1:
                        groupRequestController.OnLoadAcceptedRequests();
                        tab_option = 1;
                        break;
                    case 2:
                        groupRequestController.OnLoadDeclinedRequests();
                        tab_option = 2;
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                requests = new ArrayList<>();

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


        return view;
    }

    @Override
    public void OnPendingRequestsLoaded(List<GroupRequests> pending_requests) {
        requests = pending_requests;
        RequestsAdapter pending_adapter = new RequestsAdapter(getContext(),requests);
        requests_list.setAdapter(pending_adapter);

    }

    @Override
    public void OnAcceptedRequestsLoaded(List<GroupRequests> accepted_requests) {
        requests = accepted_requests;
        RequestsAdapter accepted_adapter = new RequestsAdapter(getContext(),requests);
        requests_list.setAdapter(accepted_adapter);
    }

    @Override
    public void OnDeclinedRequestsLoaded(List<GroupRequests> declined_requests) {
        requests = declined_requests;
        RequestsAdapter declined_adapter = new RequestsAdapter(getContext(),requests);
        requests_list.setAdapter(declined_adapter);

    }

    public void replaceFragment(Fragment fragment){
        getActivity().getSupportFragmentManager().
                beginTransaction().
                replace(R.id.frame_layout, fragment).
                setReorderingAllowed(true).
                addToBackStack(null).commit();
    }
}