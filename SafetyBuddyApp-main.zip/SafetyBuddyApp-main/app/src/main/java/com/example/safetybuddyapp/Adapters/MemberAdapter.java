package com.example.safetybuddyapp.Adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.net.URI;
import java.util.List;

public class MemberAdapter extends ArrayAdapter<User> {
    public MemberAdapter(Context context, List<User> user_list) {
        super(context, 0, user_list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.member_rows_layout,parent,false);
        }
        User user = getItem(position);
        ImageView user_profile_imageview = convertView.findViewById(R.id.user_profile_image);
        TextView user_email_textview = convertView.findViewById(R.id.user_email_textview);
        TextView user_id_textview = convertView.findViewById(R.id.user_id_textview);
        TextView user_name_textview = convertView.findViewById(R.id.user_name_textview);
        ImageView user_location_textview = convertView.findViewById(R.id.location_status_imageview);

        if(user != null){

            StorageReference storageReference = FirebaseStorage.getInstance().getReference();
            StorageReference photoReference= storageReference.child(user.getProfile_image_link());

            final long ONE_MEGABYTE = 1024 * 1024 * 5;
            photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                @Override
                public void onSuccess(byte[] bytes) {
                    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    user_profile_imageview.setImageBitmap(bmp);

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    user_profile_imageview.setImageBitmap(null);
                }
            });

            user_email_textview.setText(user.getEmail());
            user_name_textview.setText(user.getName());
            user_id_textview.setText(user.getId());
            if(user.isLocation_sharing()){
                user_location_textview.setImageResource(R.drawable.baseline_location_on_24);
            }
            else{
                user_location_textview.setImageResource(R.drawable.baseline_location_off_24);
            }
        }

        return convertView;
    }

}
