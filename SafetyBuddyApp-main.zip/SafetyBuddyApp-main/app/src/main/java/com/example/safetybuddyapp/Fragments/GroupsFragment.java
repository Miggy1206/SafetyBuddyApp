package com.example.safetybuddyapp.Fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.test.espresso.idling.CountingIdlingResource;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.safetybuddyapp.Adapters.GroupsAdapter;
import com.example.safetybuddyapp.Controllers.GroupsController;
import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.Views.IGroupsView;
import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.badge.BadgeUtils;
import com.google.android.material.badge.ExperimentalBadgeUtils;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GroupsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GroupsFragment extends Fragment implements IGroupsView {

    private List<Group> group_list = new ArrayList<>();
    GroupsController groupsController;
    Button add_group_button, confirm_add_group_button,group_requests_button;
    BottomSheetDialog add_group_bottom_sheet;
    TextView group_name_setter;
    TextInputLayout groupNameSetterLayout;
    ListView group_listview;


    private CountingIdlingResource mIdlingResource = new CountingIdlingResource("Group");
    public CountingIdlingResource getIdlingResource() {
        return mIdlingResource;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_group, container, false);

        groupsController = new GroupsController(this);



        add_group_button = (Button) view.findViewById(R.id.add_group_button);
        group_listview = view.findViewById(R.id.group_list);
        group_requests_button = view.findViewById(R.id.group_requests_button);

        groupsController.OnLoadGroups();

        group_requests_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                replaceFragment(new GroupRequestsFragment());
            }
        });

        group_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView group_id_textview = view.findViewById(R.id.group_id_textview);
                String group_id = group_id_textview.getText().toString();
                Bundle bundle = new Bundle();
                ManageGroupsFragment manageGroupsFragment = new ManageGroupsFragment();

                bundle.putString("GROUP_ID",group_id);
                manageGroupsFragment.setArguments(bundle);
                replaceFragment(manageGroupsFragment);


            }
        });



        add_group_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add_group_bottom_sheet = new BottomSheetDialog(getActivity());
                View view1 = LayoutInflater.from(getActivity()).inflate(R.layout.bottom_sheet_add_group_layout,null);
                add_group_bottom_sheet.setContentView(view1);
                add_group_bottom_sheet.show();


                confirm_add_group_button = (Button) view1.findViewById(R.id.confirm_add_group_button);
                group_name_setter = (TextView) view1.findViewById(R.id.group_name_setter);
                groupNameSetterLayout = (TextInputLayout) view1.findViewById(R.id.groupNameSetterLayout);



                confirm_add_group_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mIdlingResource.increment();
                        String group_name = group_name_setter.getText().toString();
                        Log.w("Main",group_name);
                        groupNameSetterLayout.setErrorEnabled(false);
                        groupsController.OnAddGroup(group_name);
                    }
                });



            }
        });


        return view;
    }


    @Override
    public void OnGroupsLoaded(List<Group> group_list) {
        this.group_list = group_list;
        GroupsAdapter groups_adapter = new GroupsAdapter(getContext(), this.group_list);
        group_listview.setAdapter(groups_adapter);

    }

    @Override
    public void OnGroupAddedSuccessful() {
        mIdlingResource.decrement();

    }

    @Override
    public void OnGroupAddedError() {
        groupNameSetterLayout.setError("Name field can not be null!");
        mIdlingResource.decrement();
    }

    public void replaceFragment(Fragment fragment){
        getActivity().getSupportFragmentManager().
                beginTransaction().
                replace(R.id.frame_layout, fragment).
                setReorderingAllowed(true).
                addToBackStack(null).commit();
    }

}