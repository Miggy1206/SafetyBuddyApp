package com.example.safetybuddyapp.Controllers;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Constants;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.Views.IRegisterView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;


import java.util.Date;

public class RegisterController implements Constants {

    IRegisterView registerView;
    User user = new User();

    public RegisterController(IRegisterView registerView){this.registerView = registerView;}

    public void OnRegistration(String email, String name, String phone_number, String date_of_birth, String password, String confirm_password) {

        boolean valid = true;
        Date date_of_birth_format = user.StringToDateOfBirth(date_of_birth);

        int email_code = user.is_valid_email(email);
        int name_code = user.is_valid_name(name);
        int phone_number_code = user.is_valid_phone_number(phone_number);
        int date_of_birth_code = user.is_valid_date_of_birth(date_of_birth_format);
        int password_code = user.is_valid_password(password);
        int confirm_password_code = user.is_valid_password(confirm_password);
        int equal_password_code = user.is_matching_password(password,confirm_password);

        if (email_code != VALID_FORMAT){
            valid = false;
            registerView.OnInvalidEmail(email_code);
        }

        if(name_code != VALID_FORMAT){
            valid = false;
            registerView.OnInvalidName(name_code);
        }

        if(phone_number_code != VALID_FORMAT){
            valid = false;
            registerView.OnInvalidPhoneNumber(phone_number_code);
        }

        if (date_of_birth_code != VALID_FORMAT){
            valid = false;
            registerView.OnInvalidDateOfBirth(date_of_birth_code);
        }

        if(equal_password_code != MATCHING_FIELDS){
            valid = false;
            registerView.OnInvalidMatchingPasswords(equal_password_code);
        }

        if (password_code != VALID_FORMAT){
            valid = false;
            registerView.OnInvalidPassword(password_code);
        }

        if(confirm_password_code != VALID_FORMAT){
            valid = false;
            registerView.OnInvalidConfirmPassword(confirm_password_code);
        }


        if(valid) {
            Task<AuthResult> register_response = user.register_user(email, password);
            register_response.addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                @Override
                public void onSuccess(AuthResult authResult) {
                    user.setId(authResult.getUser().getUid());
                    user.setEmail(email);
                    user.setName(name);
                    user.setPhone_number(phone_number);
                    user.setDate_of_birth(date_of_birth_format);
                    user.setLocation_sharing(false);
                    user.setCurrent_latitude(null);
                    user.setCurrent_longitude(null);
                    user.setProfile_image_link("pictures/default_profile.png");
                    user.setSecurity_code("1111");
                    user.setFalse_security_code("2222");
                    user.setDefault_group(null);
                    user.setEmergency_mode(false);
                    user.setUpdate_frequency(30);
                    user.setFcm_token(null);
                    Task<Void> firestore_response = user.add_user_to_firestore();
                    firestore_response.addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            user.send_email_verification();
                            registerView.OnRegistrationSuccess();
                        }
                    });

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    registerView.OnInvalidEmail(ALREADY_IN_USE);
                    registerView.OnRegistrationError("Error");
                }
            });
        }
        else{
            registerView.OnRegistrationError("Error");
        }
    }
}
