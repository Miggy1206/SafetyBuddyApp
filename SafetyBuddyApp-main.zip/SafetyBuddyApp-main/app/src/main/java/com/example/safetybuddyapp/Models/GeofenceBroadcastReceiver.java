package com.example.safetybuddyapp.Models;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingEvent;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.messaging.FirebaseMessagingService;

import java.util.List;

public class GeofenceBroadcastReceiver extends BroadcastReceiver {

    private Group group;
    private User user;
    @Override
    public void onReceive(Context context, Intent intent) {

        GeofencingEvent geofencingEvent = GeofencingEvent.fromIntent(intent);
        if(geofencingEvent.hasError()){
            return;
        }
        List<Geofence> geofenceList = geofencingEvent.getTriggeringGeofences();

        int transitionType = geofencingEvent.getGeofenceTransition();
        switch(transitionType){
            case Geofence.GEOFENCE_TRANSITION_ENTER:
                Toast.makeText(context, "You have entered the geofence", Toast.LENGTH_SHORT).show();
                for(Geofence geofence : geofenceList){
                    group = new Group();
                    group.get_all_groups().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if(task.isSuccessful() && !task.getResult().isEmpty()){
                                Places places = new Places();
                                places.get_places_for_group(group.getGroup_id()).addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                        if(task.isSuccessful() && !task.getResult().isEmpty()){
                                            for(Places place1 : task.getResult().toObjects(Places.class) ){
                                                if(place1.getLocation_id().equals(geofence.getRequestId())){
                                                    notify_group_members(place1.getLocation_name(),group.getGroup_members());

                                                }
                                            }
                                        }
                                    }
                                });
                            }
                        }
                    });
                }
                break;
            case Geofence.GEOFENCE_TRANSITION_EXIT:
                Toast.makeText(context, "You have left the geofence", Toast.LENGTH_SHORT).show();
                break;
            case Geofence.GEOFENCE_TRANSITION_DWELL:
                Toast.makeText(context, "You are dwelling in the geofence", Toast.LENGTH_SHORT).show();
                break;



        }

    }

    private void notify_group_members(String location_name, List<String> group_members){
        user = new User();
        for(String id: group_members){
            if(!id.equals(FirebaseAuth.getInstance().getUid())) {
                user.get_individual_user(id).addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        user = documentSnapshot.toObject(User.class);
                        FirebaseInstanceService firebaseInstanceService = new FirebaseInstanceService();
                        firebaseInstanceService.onMessageSent(user.getFcm_token(),user.getName(),user.getName()+" has entered "+ location_name,"A friend has completed a journey");
                    }
                });
            }
        }
    }
}