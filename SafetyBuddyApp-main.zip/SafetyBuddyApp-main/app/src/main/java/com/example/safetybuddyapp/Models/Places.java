package com.example.safetybuddyapp.Models;

import static com.example.safetybuddyapp.Models.Constants.GROUP_DATABASE;
import static com.example.safetybuddyapp.Models.Constants.LOCATION_COLLECTION;

import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Map;

public class Places {
    private String location_id;
    private String location_name;
    private double location_latitude;
    private double location_longitude;
    private String location_address;

    public Places(){}

    public String getLocation_id() {
        return location_id;
    }

    public double getLocation_latitude() {
        return location_latitude;
    }

    public double getLocation_longitude() {
        return location_longitude;
    }

    public String getLocation_address() {
        return location_address;
    }

    public String getLocation_name() {
        return location_name;
    }

    public void setLocation_id(String location_id) {
        this.location_id = location_id;
    }

    public void setLocation_address(String location_address) {
        this.location_address = location_address;
    }

    public void setLocation_latitude(double location_latitude) {
        this.location_latitude = location_latitude;
    }

    public void setLocation_longitude(double location_longitude) {
        this.location_longitude = location_longitude;
    }

    public void setLocation_name(String location_name) {
        this.location_name = location_name;
    }

    public Task<Void> add_place(String group_id){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .document(group_id)
                .collection(LOCATION_COLLECTION)
                .document(this.location_id)
                .set(this);
    }

    public Task<QuerySnapshot> get_places_for_group(String group_id){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .document(group_id)
                .collection(LOCATION_COLLECTION)
                .get();
    }


    public Task<Void> delete_location(String group_id,String place_id){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .document(group_id)
                .collection(LOCATION_COLLECTION)
                .document(place_id)
                .delete();
    }

}


