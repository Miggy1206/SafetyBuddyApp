package com.example.safetybuddyapp.Views;

import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.GroupRequests;
import com.example.safetybuddyapp.Models.User;

import java.util.List;

public interface IManageRequestView {
    void OnRequestLoaded(GroupRequests requests);
    void OnGroupLoaded(Group group);
    void OnGroupMembersLoaded(List<User> user_list);
    void OnRequestAccepted();
    void OnRequestDeclined();
}
