package com.example.safetybuddyapp.Views;

import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.Places;
import com.example.safetybuddyapp.Models.Reports;
import com.example.safetybuddyapp.Models.User;

import java.util.List;

public interface ILocationView {
    void OnGroupUsersLoaded(List<User> user_list);
    void OnGroupsLoaded(List<Group> group_list);
    void OnLocationsLoaded(List<Places> places_list);
    void OnGeofencesLoaded(List<Places> geofence_list);
    void OnReportsLoaded(List<Reports> reports_list);
    void OnUserLoaded(User user);
    void OnRuleApplied(boolean rule_applicable);
    void OnEmergencyModeStopped();
    void OnEmergencyModeStoppedFake();
    void OnInvalidSecurityCode();
}
