package com.example.safetybuddyapp.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.safetybuddyapp.Models.GroupRequests;
import com.example.safetybuddyapp.Models.Places;
import com.example.safetybuddyapp.R;

import java.text.DecimalFormat;
import java.util.List;

public class PlacesAdapter extends ArrayAdapter<Places> {
    private DecimalFormat dec = new DecimalFormat("0.00");
    public PlacesAdapter(Context context, List<Places> placesList) {
        super(context, 0,placesList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.places_rows_layout,parent,false);
        }


        Places place = getItem(position);
        TextView place_id_textview = convertView.findViewById(R.id.place_id_textview);
        TextView place_name_textview = convertView.findViewById(R.id.place_name_textview);
        TextView place_address_textview = convertView.findViewById(R.id.place_address_textview);
        TextView place_latitude_textview = convertView.findViewById(R.id.place_latitude_textview);
        TextView place_longitude_textview = convertView.findViewById(R.id.place_longitude_textview);

        if(place != null){
            place_id_textview.setText(place.getLocation_id());
            place_name_textview.setText(place.getLocation_name());
            place_address_textview.setText(new StringBuilder().append("Address: ").append(place.getLocation_address()).toString());
            place_latitude_textview.setText(new StringBuilder().append("Latitude: ").append(String.valueOf(dec.format(place.getLocation_latitude()))).toString());
            place_longitude_textview.setText(new StringBuilder().append("Longitude: ").append(String.valueOf(dec.format(place.getLocation_longitude()))).toString());
        }

        return convertView;
    }
}
