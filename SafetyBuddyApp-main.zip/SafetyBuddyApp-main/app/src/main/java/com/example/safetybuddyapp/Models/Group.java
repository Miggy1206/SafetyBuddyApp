package com.example.safetybuddyapp.Models;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Group implements Constants{
    private String group_id;
    private String group_name;
    private String group_admin;
    private String group_profile_image;
    private List<String> group_members;

    public Group(){}

    @NonNull
    @Override
    public String toString() {
        return group_name;
    }

    public String getGroup_id() { return group_id;}
    public String getGroup_name() { return group_name; }
    public String getGroup_profile_image() { return group_profile_image; }
    public List<String> getGroup_members() { return group_members; }

    public String getGroup_admin() {
        return group_admin;
    }

    public void setGroup_id(String group_id) { this.group_id = group_id; }
    public void setGroup_name(String group_name) {this.group_name = group_name;}
    public void setGroup_profile_image(String group_profile_image) { this.group_profile_image = group_profile_image; }
    public void setGroup_members(List<String> group_members) { this.group_members = group_members; }

    public void setGroup_admin(String group_admin) {
        this.group_admin = group_admin;
    }

    public Task<QuerySnapshot> get_groups_for_user(String user_id){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .whereArrayContains("group_members",user_id)
                .get();
    }

    public Task<DocumentSnapshot> get_single_group(String group_id){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .document(group_id)
                .get();
    }

    public Task<QuerySnapshot> get_all_groups(){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .get();
    }
    public Task<Void> add_group(Map<String,Object> group_instance){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .document(group_instance.get("group_id").toString())
                .set(group_instance);
    }

    public Task<Void> delete_group(String group_id){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .document(group_id)
                .delete();
    }

    public Task<Void> update_group_name(String group_id, String new_group_name){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .document(group_id)
                .update("group_name", new_group_name);
    }

    public Task<Void> change_admin(String group_id, String admin_id){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .document(group_id)
                .update("group_admin", admin_id);
    }


    public Task<Void> add_user_to_group(String group_id, String member_id){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .document(group_id)
                .update("group_members", FieldValue.arrayUnion(member_id));
    }

    public Task<Void> delete_member(String group_id, String member_id){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .document(group_id)
                .update("group_members", FieldValue.arrayRemove(member_id));
    }

    public Task<Void> update_cover_image(String group_id,String new_image_link){
        return FirebaseFirestore.getInstance()
                .collection(GROUP_DATABASE)
                .document(group_id)
                .update("group_profile_image",new_image_link);
    }


}
