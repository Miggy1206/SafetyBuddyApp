package com.example.safetybuddyapp.Views;

import android.location.Address;

import com.example.safetybuddyapp.Models.Places;

import java.util.List;

public interface IManageLocationsView {
    void OnAddressFound(Address address);
    void OnPlacesLoaded(List<Places> places);
    void OnInvalidAddress();
    void OnAddressNotFound();
    void OnLocationDeleted();
}
