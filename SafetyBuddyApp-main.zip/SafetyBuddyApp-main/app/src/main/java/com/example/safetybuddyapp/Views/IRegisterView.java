package com.example.safetybuddyapp.Views;

public interface IRegisterView {
    void OnRegistrationSuccess();
    void OnRegistrationError(String error_message);
    void OnInvalidEmail(int decline_code);
    void OnInvalidPassword(int decline_code);
    void OnInvalidName(int decline_code);
    void OnInvalidPhoneNumber(int decline_code);
    void OnInvalidDateOfBirth(int decline_code);
    void OnInvalidConfirmPassword(int decline_code);
    void OnInvalidMatchingPasswords(int decline_code);
}
