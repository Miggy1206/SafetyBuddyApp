package com.example.safetybuddyapp.Adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.List;

public class GroupsAdapter extends ArrayAdapter<Group> {
    public GroupsAdapter(Context context, List<Group> group_list) {
        super(context, 0, group_list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.group_rows_layout,parent,false);
        }
        Group group = getItem(position);
        ImageView group_profile_imageview = convertView.findViewById(R.id.group_profile_image);
        TextView group_id_textview = convertView.findViewById(R.id.group_id_textview);
        TextView group_name_textview = convertView.findViewById(R.id.group_name_textview);
        TextView group_members_textview = convertView.findViewById(R.id.group_members_textview);

        if(group != null){

            StorageReference storageReference = FirebaseStorage.getInstance().getReference();
            StorageReference photoReference= storageReference.child(group.getGroup_profile_image());

            final long ONE_MEGABYTE = 1024 * 1024 * 5;
            photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                @Override
                public void onSuccess(byte[] bytes) {
                    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    group_profile_imageview.setImageBitmap(bmp);

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    group_profile_imageview.setImageBitmap(null);
                }
            });


            group_id_textview.setText(group.getGroup_id());
            group_name_textview.setText(group.getGroup_name());
            group_members_textview.setText(new StringBuilder().append("Members:").append(group.getGroup_members().size()).toString());
        }

        return convertView;
    }
}
