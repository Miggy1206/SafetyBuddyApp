package com.example.safetybuddyapp.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import com.example.safetybuddyapp.Adapters.MemberAdapter;
import com.example.safetybuddyapp.Controllers.ManageRequestController;
import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.GroupRequests;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.Views.IManageRequestView;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ManageRequestFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ManageRequestFragment extends Fragment implements IManageRequestView {

    private ManageRequestController manageRequestController;
    private String request_id;
    private GroupRequests loaded_request;
    private Group loaded_group;
    private Button accept_button,decline_button, request_back_button;
    private ListView member_list;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_manage_request, container, false);
        manageRequestController = new ManageRequestController(this);
        accept_button = view.findViewById(R.id.accept_button);
        decline_button = view.findViewById(R.id.decline_button);
        member_list = view.findViewById(R.id.members_list);

        request_id = getArguments().getString("REQUEST_ID");
        manageRequestController.OnLoadRequest(request_id);


        accept_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                manageRequestController.OnAcceptRequest(loaded_request,loaded_group);
            }
        });
        decline_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                manageRequestController.OnDeclineRequest(loaded_request);
            }
        });

        return view;
    }

    @Override
    public void OnRequestLoaded(GroupRequests requests) {
        this.loaded_request = requests;
    }

    @Override
    public void OnGroupLoaded(Group group) {
        this.loaded_group = group;
        manageRequestController.OnLoadGroupMembers(group.getGroup_members());

    }

    @Override
    public void OnGroupMembersLoaded(List<User> user_list) {
        MemberAdapter memberAdapter = new MemberAdapter(getContext(),user_list);
        member_list.setAdapter(memberAdapter);
    }

    @Override
    public void OnRequestAccepted() {
        getParentFragmentManager().popBackStack();
    }

    @Override
    public void OnRequestDeclined() {
        getParentFragmentManager().popBackStack();
    }
}