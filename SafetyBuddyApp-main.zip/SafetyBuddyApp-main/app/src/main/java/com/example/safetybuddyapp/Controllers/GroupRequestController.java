package com.example.safetybuddyapp.Controllers;

import android.util.Log;

import androidx.annotation.NonNull;

import com.example.safetybuddyapp.Models.GroupRequests;
import com.example.safetybuddyapp.Views.IGroupRequestsView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

public class GroupRequestController {
    private IGroupRequestsView groupRequestsView;
    private GroupRequests groupRequests;
    public GroupRequestController(IGroupRequestsView groupRequestsView){this.groupRequestsView = groupRequestsView;}

    public void OnLoadPendingRequests(){
        groupRequests = new GroupRequests();
        Task<QuerySnapshot> pending_result = groupRequests.get_pending_requests_for_user(FirebaseAuth.getInstance().getUid());
        pending_result.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull  Task<QuerySnapshot> task) {
                if(task.isSuccessful() && task.getResult()!=null){
                    List<GroupRequests> pending_list = task.getResult().toObjects(GroupRequests.class);
                    groupRequestsView.OnPendingRequestsLoaded(pending_list);
                }
            }
        });
    }

    public void OnLoadAcceptedRequests(){
        this.groupRequests = new GroupRequests();
        Task<QuerySnapshot> accepted_result = groupRequests.get_accepted_requests_for_user(FirebaseAuth.getInstance().getUid());
        accepted_result.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful() && task.getResult()!=null){
                    List<GroupRequests> accepted_list = task.getResult().toObjects(GroupRequests.class);
                    groupRequestsView.OnAcceptedRequestsLoaded(accepted_list);
                }
            }
        });

    }
    public void OnLoadDeclinedRequests(){
        this.groupRequests = new GroupRequests();
        Task<QuerySnapshot> declined_result = groupRequests.get_declined_requests_for_user(FirebaseAuth.getInstance().getUid());
        declined_result.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful() && task.getResult()!=null){
                    List<GroupRequests> declined_list = task.getResult().toObjects(GroupRequests.class);
                    groupRequestsView.OnDeclinedRequestsLoaded(declined_list);
                }
            }
        });
    }


}
