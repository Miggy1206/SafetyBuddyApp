package com.example.safetybuddyapp.Fragments;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.widget.ImageViewCompat;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.safetybuddyapp.Adapters.AddMemberAdapter;
import com.example.safetybuddyapp.Adapters.GroupsAdapter;
import com.example.safetybuddyapp.Adapters.MemberAdapter;
import com.example.safetybuddyapp.Controllers.ManageGroupsController;
import com.example.safetybuddyapp.Models.Group;
import com.example.safetybuddyapp.Models.User;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.Views.IManageGroupsView;
import com.google.firebase.auth.FirebaseAuth;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ManageGroupsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ManageGroupsFragment extends Fragment implements IManageGroupsView {
    private Group group;
    private List<User> member_list = new ArrayList<>();
    private List<User> available_friends_list = new ArrayList<>();
    private String group_id;
    private String user_id;
    private ActivityResultLauncher<String> takePhoto;
    ManageGroupsController manageGroupsController;
    ListView member_listview;
    Button manage_group_back_button, add_members_button,leave_group_button,cancel_button,confirm_leave_button, change_image_button;
    Dialog dialog, leave_group_dialog, manage_member_dialog;
    ListView listView;
    ImageView group_cover_image;
    TextView group_title;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_manage_groups, container, false);
        manageGroupsController = new ManageGroupsController(this);
        group_id  = getArguments().getString("GROUP_ID");
        member_listview = view.findViewById(R.id.member_list);
        manage_group_back_button = view.findViewById(R.id.manage_group_back_button);
        add_members_button = view.findViewById(R.id.add_members_button);
        leave_group_button = view.findViewById(R.id.leave_button);
        group_cover_image = view.findViewById(R.id.group_cover_image);
        change_image_button = view.findViewById(R.id.change_image_button);
        group_title = view.findViewById(R.id.group_title);

        manageGroupsController.OnLoadGroup(group_id);


        leave_group_dialog = new Dialog(getActivity());
        leave_group_dialog.setContentView(R.layout.leave_group_dialog);
        leave_group_dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        leave_group_dialog.setCancelable(true);
        cancel_button = leave_group_dialog.findViewById(R.id.cancel_button);
        confirm_leave_button = leave_group_dialog.findViewById(R.id.confirm_leave_button);


        manage_member_dialog = new Dialog(getActivity());
        manage_member_dialog.setContentView(R.layout.manage_user_dialog);
        manage_member_dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        manage_member_dialog.setCancelable(true);
        Button change_admin_button= manage_member_dialog.findViewById(R.id.change_admin_button);
        Button remove_member_button= manage_member_dialog.findViewById(R.id.remove_member_button);


        dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.add_member_dialogue);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);
        TextView search_friend_input = dialog.findViewById(R.id.search_friend_input);
        listView = dialog.findViewById(R.id.add_member_listview);




        takePhoto = registerForActivityResult(new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
            @Override
            public void onActivityResult(Uri o) {
                InputStream imageStream = null;
                try {
                    imageStream = getContext().getContentResolver().openInputStream(o);
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
                if(imageStream!=null) {
                    Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                    group_cover_image.setImageBitmap(selectedImage);
                    manageGroupsController.OnUpdateCoverImage(group, selectedImage);
                }
            }
        });




        change_image_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePhoto.launch("image/*");
            }
        });


        member_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView user_id_textview = view.findViewById(R.id.user_id_textview);
                user_id = user_id_textview.getText().toString();
                if(group.getGroup_admin().equals(FirebaseAuth.getInstance().getUid())
                && !user_id.equals(FirebaseAuth.getInstance().getUid())){
                    manage_member_dialog.show();
                }
            }
        });


        remove_member_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                manageGroupsController.OnRemoveMember(user_id,group);
            }
        });

        change_admin_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                manageGroupsController.OnChangeAdmin(user_id,group.getGroup_id());
            }
        });




        leave_group_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                leave_group_dialog.show();
            }
        });

        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                leave_group_dialog.hide();
            }
        });
        confirm_leave_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                manageGroupsController.OnLeaveGroup(group);
            }
        });

        add_members_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.show();


            }
        });

        search_friend_input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                List<User> user_searched = new ArrayList<>();
                String search = charSequence.toString().toLowerCase();
                for (User user: available_friends_list){
                    if (user.getName().toLowerCase().equals(search) || user.getEmail().toLowerCase().equals(search)){
                        user_searched.add(user);
                    }
                }

                AddMemberAdapter adapter = new AddMemberAdapter(getContext(), user_searched,group);
                listView.setAdapter(adapter);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        manage_group_back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getParentFragmentManager().popBackStack();
            }
        });




        return view;
    }

    @Override
    public void OnGroupLoaded(Group group) {
        this.group = group;
        group_title.setText(group.getGroup_name());
        if(group.getGroup_admin().equals(FirebaseAuth.getInstance().getUid())){
            add_members_button.setVisibility(View.VISIBLE);
            change_image_button.setVisibility(View.VISIBLE);
            add_members_button.setClickable(true);
            change_image_button.setClickable(true);
        }

    }

    @Override
    public void OnMembersLoaded(List<User> user_list) {
        this.member_list = user_list;
        MemberAdapter groups_adapter = new MemberAdapter(getContext(), user_list);
        member_listview.setAdapter(groups_adapter);
    }

    @Override
    public void OnFriendsAvailableLoaded(List<User> user_list) {
        this.available_friends_list = user_list;
    }

    @Override
    public void OnCoverImageLoaded(Bitmap cover_image) {
        group_cover_image.setImageBitmap(cover_image);
    }
}