package com.example.safetybuddyapp;

import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withChild;
import static androidx.test.espresso.matcher.ViewMatchers.withClassName;
import static androidx.test.espresso.matcher.ViewMatchers.withContentDescription;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

import static java.util.EnumSet.allOf;

import android.Manifest;
import android.app.DatePickerDialog;
import android.service.credentials.Action;
import android.view.View;
import android.widget.DatePicker;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.IdlingRegistry;
import androidx.test.espresso.UiController;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.contrib.PickerActions;
import androidx.test.espresso.idling.CountingIdlingResource;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.rule.GrantPermissionRule;

import com.example.safetybuddyapp.Activities.LoginActivity;
import com.example.safetybuddyapp.Activities.RegisterActivity;
import com.example.safetybuddyapp.Models.Constants;
import com.google.firebase.auth.FirebaseAuth;
import com.google.type.DateTime;

import org.hamcrest.Matchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.util.Calendar;
import java.util.Date;

public class RegisterTests implements Constants {

    private CountingIdlingResource idlingResource;

    LocalDate today = LocalDate.now();

    @Rule
    public ActivityScenarioRule<RegisterActivity> activityRule =
            new ActivityScenarioRule<RegisterActivity>(RegisterActivity.class);

    @Rule
    public GrantPermissionRule permissionRule = GrantPermissionRule.grant(
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_BACKGROUND_LOCATION,
            android.Manifest.permission.POST_NOTIFICATIONS);

    @Before
    public void registerIdlingResource() {
        activityRule.getScenario().onActivity(new ActivityScenario.ActivityAction<RegisterActivity>() {
            @Override
            public void perform(RegisterActivity activity) {
                idlingResource = activity.getIdlingResource();
                IdlingRegistry.getInstance().register(idlingResource);
            }
        });
    }





    @Test
    public void registerExistingEmailCase() {
        String alreadyExistingCaseEmail = "unverifiedemail@gmail.com";
        String normalCasePassword = "password";
        String normalCaseName = "TestUser";
        String normalCasePhoneNumber = "07300000000";
        int[] normalCaseDateOfBirth = {2002,1,1};

        onView(withId(R.id.email))
                .perform(typeText(alreadyExistingCaseEmail));

        onView(withId(R.id.name))
                .perform(typeText(normalCaseName));

        onView(withId(R.id.phone_number))
                .perform(typeText(normalCasePhoneNumber));


        onView(withId(R.id.date_of_birth)).perform(click());

        onView(withClassName(containsString("DatePicker")))
                .perform(PickerActions.setDate(normalCaseDateOfBirth[0], normalCaseDateOfBirth[1], normalCaseDateOfBirth[2]));


        onView(withText("OK")).perform(click());

        onView(withId(R.id.password))
                .perform(typeText(normalCasePassword));

        onView(withId(R.id.confirmPassword))
                .perform(typeText(normalCasePassword),closeSoftKeyboard());

        onView(withId(R.id.registerButton))
                .perform(click());

        onView(withId(R.id.emailLayout))
                .check(matches(hasDescendant(withText(EMAIL_IN_USE_ERROR))));

    }


    @Test
    public void registerInvalidEmailCase() {
        String alreadyExistingCaseEmail = "invalid";
        String normalCasePassword = "password";
        String normalCaseName = "TestUser";
        String normalCasePhoneNumber = "07300000000";
        int[] normalCaseDateOfBirth = {2002,1,1};

        onView(withId(R.id.email))
                .perform(typeText(alreadyExistingCaseEmail));

        onView(withId(R.id.name))
                .perform(typeText(normalCaseName));

        onView(withId(R.id.phone_number))
                .perform(typeText(normalCasePhoneNumber));


        onView(withId(R.id.date_of_birth)).perform(click());

        onView(withClassName(containsString("DatePicker")))
                .perform(PickerActions.setDate(normalCaseDateOfBirth[0], normalCaseDateOfBirth[1], normalCaseDateOfBirth[2]));


        onView(withText("OK")).perform(click());

        onView(withId(R.id.password))
                .perform(typeText(normalCasePassword));

        onView(withId(R.id.confirmPassword))
                .perform(typeText(normalCasePassword),closeSoftKeyboard());

        onView(withId(R.id.registerButton))
                .perform(click());

        onView(withId(R.id.emailLayout))
                .check(matches(hasDescendant(withText(EMAIL_INVALID_FORMAT_ERROR))));

    }


    @Test
    public void registerFutureDateOfBirthCase() {
        String alreadyExistingCaseEmail = "emailaddress@gmail.com";
        String normalCasePassword = "password";
        String normalCaseName = "TestUser";
        String normalCasePhoneNumber = "07300000000";
        int[] futureCaseDateOfBirth = {today.getYear()+10,today.getMonthValue(),today.getDayOfMonth()};

        onView(withId(R.id.email))
                .perform(typeText(alreadyExistingCaseEmail));

        onView(withId(R.id.name))
                .perform(typeText(normalCaseName));

        onView(withId(R.id.phone_number))
                .perform(typeText(normalCasePhoneNumber));


        onView(withId(R.id.date_of_birth)).perform(click());

        onView(withClassName(containsString("DatePicker")))
                .perform(PickerActions.setDate(futureCaseDateOfBirth[0], futureCaseDateOfBirth[1], futureCaseDateOfBirth[2]));


        onView(withText("OK")).perform(click());

        onView(withId(R.id.password))
                .perform(typeText(normalCasePassword));

        onView(withId(R.id.confirmPassword))
                .perform(typeText(normalCasePassword),closeSoftKeyboard());

        onView(withId(R.id.registerButton))
                .perform(click());

        onView(withId(R.id.dateOfBirthLayout))
                .check(matches(hasDescendant(withText(BIRTH_ILLOGICAL_FIELD_ERROR))));

    }

    @Test
    public void registerEmptyFieldsCase() {



        onView(withId(R.id.registerButton))
                .check(matches(isDisplayed()))
                .perform(click());

        onView(withId(R.id.emailLayout)).check(matches(hasDescendant(withText(EMAIL_EMPTY_FIELD_ERROR))));
        onView(withId(R.id.nameLayout)).check(matches(hasDescendant(withText(NAME_EMPTY_FIELD_ERROR))));
        onView(withId(R.id.phoneNumberLayout)).check(matches(hasDescendant(withText(PHONE_NUMBER_EMPTY_FIELD_ERROR))));
        onView(withId(R.id.dateOfBirthLayout)).check(matches(hasDescendant(withText(BIRTH_EMPTY_FIELD_ERROR))));
        onView(withId(R.id.passwordLayout)).check(matches(hasDescendant(withText(PASSWORD_EMPTY_FIELD_MESSAGE))));
        onView(withId(R.id.confirmPasswordLayout)).check(matches(hasDescendant(withText(PASSWORD_EMPTY_FIELD_MESSAGE))));

    }







    @After
    public void unregisterIdlingResource() {
        activityRule.getScenario().onActivity(new ActivityScenario.ActivityAction<RegisterActivity>() {
            @Override
            public void perform(RegisterActivity activity) {
                idlingResource = activity.getIdlingResource();
                IdlingRegistry.getInstance().unregister(idlingResource);
            }
        });
    }
}
