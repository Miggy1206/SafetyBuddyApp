package com.example.safetybuddyapp.GroupTests;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import static org.junit.Assert.assertNotNull;

import android.Manifest;
import android.content.pm.PackageManager;

import androidx.core.app.ActivityCompat;
import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.IdlingRegistry;
import androidx.test.espresso.idling.CountingIdlingResource;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.GrantPermissionRule;

import com.example.safetybuddyapp.Activities.MainActivity;
import com.example.safetybuddyapp.Fragments.GroupsFragment;
import com.example.safetybuddyapp.R;
import com.example.safetybuddyapp.TestUtils.SignInUtil;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

@RunWith(AndroidJUnit4.class)
public class AddGroupTests {
    private GroupsFragment groupsFragment;

    @Rule
    public ActivityScenarioRule<MainActivity> scenarioRule = new ActivityScenarioRule<>(MainActivity.class);

    @Rule
    public GrantPermissionRule permissionRule = GrantPermissionRule.grant(
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_BACKGROUND_LOCATION,
            android.Manifest.permission.POST_NOTIFICATIONS);





    @Before
    public void SignIn() throws InterruptedException {
        SignInUtil sign = new SignInUtil();
        CountingIdlingResource idlingResource = sign.getIdlingResource();
        sign.sign_in();

        Espresso.onIdle();

        assertNotNull("FirebaseAuth user is null", FirebaseAuth.getInstance().getCurrentUser());

        scenarioRule.getScenario().onActivity(new ActivityScenario.ActivityAction<MainActivity>() {
            @Override
            public void perform(MainActivity activity) {
                groupsFragment = new GroupsFragment();
                activity.getSupportFragmentManager().beginTransaction()
                        .replace(R.id.frame_layout, groupsFragment).commitNow();
            }
        });

        CountingIdlingResource fragmentIdlingResource = groupsFragment.getIdlingResource();
        IdlingRegistry.getInstance().register(fragmentIdlingResource);

    }

    




    @Test
    public void addGroupNormalCase() {
        String normalCaseGroupName= "Name";


        onView(withId(R.id.add_group_button))
                .perform(click());

        onView(withId(R.id.group_name_setter))
                .perform(typeText(normalCaseGroupName));

        onView(withId(R.id.confirm_add_group_button))
                .perform(click());


    }


    @After
    public void tearDown() {
        // Unregister the idling resource to prevent memory leaks
        IdlingRegistry.getInstance().unregister(groupsFragment.getIdlingResource());
    }
}
