package com.example.safetybuddyapp;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.*;
import static androidx.test.espresso.assertion.ViewAssertions.*;
import static androidx.test.espresso.matcher.ViewMatchers.*;

import android.Manifest;
import android.provider.Settings;

import androidx.test.InstrumentationRegistry;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.intent.matcher.IntentMatchers;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.IdlingRegistry;
import androidx.test.espresso.ViewAssertion;
import androidx.test.espresso.idling.CountingIdlingResource;
import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.LargeTest;
import androidx.test.rule.GrantPermissionRule;
import androidx.test.uiautomator.UiDevice;

import com.example.safetybuddyapp.Activities.LoginActivity;
import com.example.safetybuddyapp.Activities.MainActivity;
import com.example.safetybuddyapp.Fragments.LocationFragment;
import com.example.safetybuddyapp.Models.Constants;
import com.google.firebase.auth.FirebaseAuth;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;


    /*
        What test exceptions mean:
            - PerformException: The tested code has crashed the app
            - NoMatchingViewException: No red text is found when expected

     */

@RunWith(AndroidJUnit4.class)
@LargeTest
public class LoginTests  implements Constants {


    private CountingIdlingResource idlingResource;

    @Rule
    public ActivityScenarioRule<LoginActivity> activityRule =
            new ActivityScenarioRule<LoginActivity>(LoginActivity.class);

    @Rule
    public GrantPermissionRule permissionRule = GrantPermissionRule.grant(
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_BACKGROUND_LOCATION,
            android.Manifest.permission.POST_NOTIFICATIONS);


    @Before
    public void registerIdlingResource() {
        activityRule.getScenario().onActivity(new ActivityScenario.ActivityAction<LoginActivity>() {
            @Override
            public void perform(LoginActivity activity) {
                idlingResource = activity.getIdlingResource();
                IdlingRegistry.getInstance().register(idlingResource);
            }
        });
    }



    

    @Test
    public void loginInvalidEmailCase() {
        String normalCaseEmail = "invalid";
        String normalCasePassword = "password";

        onView(withId(R.id.email))
                .perform(typeText(normalCaseEmail));

        onView(withId(R.id.password))
                .perform(typeText(normalCasePassword));

        onView(withId(R.id.loginButton))
                .perform(click());

        onView(withId(R.id.emailLayout))
                .check(matches(hasDescendant(withText(EMAIL_INVALID_FORMAT_ERROR))));


    }

    @Test
    public void loginUnverifiedEmailCase() {
        String normalCaseEmail = "unverifiedEmail@gmail.com";
        String normalCasePassword = "password";


        onView(withId(R.id.email))
                .perform(typeText(normalCaseEmail));

        onView(withId(R.id.password))
                .perform(typeText(normalCasePassword));

        onView(withId(R.id.loginButton))
                .perform(click());

        onView(withId(R.id.emailLayout))
                .check(matches(hasDescendant(withText(EMAIL_NOT_VERIFIED_ERROR))));

    }

    @Test
    public void loginEmptyFieldsCase()  {

        onView(withId(R.id.loginButton))
                .check(matches(isDisplayed()))
                .perform(click());

        onView(withId(R.id.emailLayout))
                .check(matches(hasDescendant(withText(EMAIL_EMPTY_FIELD_ERROR))));
        onView(withId(R.id.passwordLayout))
                .check(matches(hasDescendant(withText(PASSWORD_EMPTY_FIELD_MESSAGE))));


    }

    @Test
    public void loginEmptyEmailFieldCase() {

        onView(withId(R.id.loginButton))
                .check(matches(isDisplayed()))
                .perform(click());

        onView(withId(R.id.emailLayout))
                .check(matches(hasDescendant(withText(EMAIL_EMPTY_FIELD_ERROR))));


    }

    @Test
    public void loginEmptyPasswordFieldCase() {

        onView(withId(R.id.loginButton))
                .check(matches(isDisplayed()))
                .perform(click());

        onView(withId(R.id.passwordLayout))
                .check(matches(hasDescendant(withText(PASSWORD_EMPTY_FIELD_MESSAGE))));


    }




    @After
    public void unregisterIdlingResource() {
        activityRule.getScenario().onActivity(new ActivityScenario.ActivityAction<LoginActivity>() {
            @Override
            public void perform(LoginActivity activity) {
                idlingResource = activity.getIdlingResource();
                IdlingRegistry.getInstance().unregister(idlingResource);
            }
        });
    }




}
