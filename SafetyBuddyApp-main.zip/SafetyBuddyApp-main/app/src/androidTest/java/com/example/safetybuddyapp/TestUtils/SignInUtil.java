package com.example.safetybuddyapp.TestUtils;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.test.espresso.idling.CountingIdlingResource;

import com.example.safetybuddyapp.Models.User;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class SignInUtil {
        private FirebaseAuth mAuth;
        private User user;
        private final String email = "miguelsbarbosa123@gmail.com";
        private final String password = "password";



        private CountingIdlingResource idlingResource = new CountingIdlingResource("Sign In");

        public void sign_in() {
            idlingResource.increment();

            user.login_user(email,password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                @Override
                public void onSuccess(AuthResult authResult) {
                    idlingResource.decrement();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    idlingResource.decrement();
                }
            });

        }

        public CountingIdlingResource getIdlingResource() {
            return idlingResource;
        }
}
